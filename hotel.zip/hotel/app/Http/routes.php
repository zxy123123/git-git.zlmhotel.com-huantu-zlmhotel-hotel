<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});




Route::group(['middleware'=>'login'],function(){
//后台首页的路由规则
Route::get('/admin','AdminController@index');

//后台用户管理
// Route::get('/admin/user/edit/{id}','UserController@edit');
Route::controller('admin/user','UserController');

//后台分类管理
Route::controller('admin/cate','CateController');

//订单管理
Route::controller('admin/order','OrderController');

//酒店管理
Route::controller('admin/hotel','HotelController');

//房间管理
Route::controller('admin/room','RoomController');

//前台用户管理
Route::controller('admin/member','MemberController');

//积分管理
Route::controller('admin/score','ScoreController');

//城市管理
Route::controller('admin/city','CityController');

//贴吧管理
Route::controller('admin/tieba','TiebaController');

//商品管理
Route::controller('admin/goods','GoodsController');

//在线商城
Route::controller('admin/store','StoreController');

//加入我们
Route::controller('admin/join','JoinController');

// 上传页面视图
// Route::get('/upload',function ()
// {
//     return view('hotel.editpic');
// });

// form提交到控制器路由
// Route::post('upload','UploadController@uploadFile');




        Route::post('queren','PollController@queren');
});

//后台登录
Route::get('/admin/login','LoginController@login');
Route::post('/admin/login','LoginController@dologin');
Route::get('/admin/loginout','LoginController@loginout');