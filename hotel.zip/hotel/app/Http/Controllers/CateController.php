<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CateController extends Controller
{
    /**
     * 获取分类下所有的分类 按照顺序来获取
     */
    public static function getCates()
    {
        $res = DB::table('categroy')
                ->select(DB::raw('id,path,pid,cname,concat(path,id) as paths'))//用原生SQL语句就用DB::raw
                ->orderBy('paths')
                ->get();
        //调整分类名称
        foreach ($res as $key => $val) 
        {
            //拆分数组
            $tmp = explode(',', $val['path']);
            $len = count($tmp) - 1;
            //修改分类名称
            $res[$key]['cname'] = str_repeat('|----', $len).$val['cname'];
            // var_dump($len);

        }
        // var_dump($res);die;
        return $res;
    } 

    /**
     * 用户的添加页面显示
     */
    public function getAdd()
    {
       $cates = self::getCates();
        //获取所有分类信息
        // $cates = DB::table('categroy')->get();
        // dd($cates);
        //显示一个form表单
        return view('cate.add',['cates'=>$cates]);
    }

    /**
     * 执行添加
     */
    public function postInsert(Request $request)
    {
        $data = array();
        //获取父级分类id参数
        $pid = $request->input('pid');
        //判断
        $data = $request->except('_token');
        if ($pid == 0) 
        {
            $data['path'] = '0,';
        }else{
            //获取pid并读取父级分类的信息
            $info = DB::table('categroy')->where('id','=',$pid)->first();
            //拼接path路径
            $data['path'] = $info->path.$info->id.',';
            // dd($data);
        }
        // dd($data);

        $res = DB::table('categroy')->insert($data);

        if ($res) 
        {
            return redirect('/admin/cate/index')->with('success','添加成功');
        }else{
            return back()->with('error','添加失败');
        }
        
    }
    /**
     * 分类的列表显示
     */

    public function getIndex()
    {
        //读取分类
        $cates = self::getCates();
        return view('cate.index',['cates'=>$cates]);
    }

    /**
     * 分类的修改操作
     */
    public function getEdit($id)
    {
        //读取当前id的分类信息
        $info = DB::table('categroy')->where('id','=',$id)->first();
        // dd($info);
        //分配变量解析模板
        return view('cate.edit',['cates'=>self::getCates()],['info'=>$info]);
    }

    /**
     * 执行分类修改
     */
    public function postUpdate(Request $request)
    {
        // dd($request->all());
        $data = array();
        //判断
        $data = $request->except('_token');
        $res = DB::table('categroy')->where('id','=',$request->input('id'))->update($data);

        if ($res) 
        {
            return redirect('/admin/cate/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
    }

    /**
     * 分类删除
     */
    public function getDelete($id)
    {

        //检测当前分类下是否包含子分类
        $data = DB::table('categroy')->where('pid','=',$id)->count();
        // dd($data);
        if ($data >0) 
        {
            return back()->with('error','对不起,有子分类,不允许删除');
        }
        //删除
        $res = DB::table('categroy')->where('id','=',$id)->delete();
        if ($res) 
        {
            return redirect('/admin/cate/index')->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }








}
