<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class JoinController extends Controller
{
    /**
     * 申请记录
     */
    public function getIndex(Request $request)
    {
        $list = DB::table('contants')
                    ->where(function($query) use ($request){
                        $query->where('contants.name','like','%'.$request->input('keywords').'%');
                    })
                    ->paginate(6);
        // var_dump($list);
        return view('join.index',['list'=>$list,'request'=>$request->all()]);
    }


}
