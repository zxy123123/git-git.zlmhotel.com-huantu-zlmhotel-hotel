<?php 
namespace App\Http\Controllers\Ajax;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Poll;
use DB;
use Session;
use Illuminate\Http\Response;

    class PollController extends Controller
    {
        public function queren(Request $request)
        {
            $data = $_POST;
            dd($data);
        }










    }















 ?>