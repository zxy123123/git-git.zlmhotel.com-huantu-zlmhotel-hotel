<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class MemberController extends Controller
{
    /**
     * 前台用户
     * 
     */
    public function getIndex(Request $request)
    {
        $res = DB::table('users')
                // ->join('hotels','hotels.id','=','users.hotel_id')
                // ->join('user_usual_infos','user_usual_infos.user_id','=','users.id')
                ->where(function($query) use ($request){
                    $query->where('users.nickname','like','%'.$request->input('keywords').'%');
                })
                ->paginate(6);
                // var_dump($res);
        //解析模板
        return view('member.index',['res'=>$res,'request'=>$request->all()]);
    }

    /**
     * 修改备注
    */
    public function postEdmask(Request $request)
    {
        // var_dump($request->all());
        $this->validate($request,[
            'mark' => 'required',
            ],[
            'mark.required' => '请输入备注',
            ]);
        //获取参数
        $data = $request->only('mark','id');
        $res = DB::table('users')->where('id','=',$request->input('id'))->update($data);
        if ($res) 
        {
            return redirect('/admin/member/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
    }



}
