<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class TiebaController extends Controller
{
    /*
    *贴吧管理
     */
    public function getIndex(Request $request)
    {
        $list = DB::table('tieba_topics')
        ->join('tiebas','tieba_topics.tieba_id','=','tiebas.id')
        ->join('tieba_classifies','tieba_topics.classify_id','=','tieba_classifies.id')
        ->join('users','tieba_topics.user_id','=','users.id')
        ->where(function($query) use ($request){
            $query->where('users.nickname','like','%'.$request->input('keywords').'%');
        })
        ->select('tieba_topics.*','users.nickname','tiebas.display_name as tdn','tieba_classifies.display_name as tcdn')
        ->paginate(6);
        // var_dump($list);
        return view('tieba.index',['list'=>$list,'request'=>$request->all()]);
    }

    /*
    *删除帖子
     */
    public function getDel($id)
    {
        $list = DB::table('tieba_topics')->where('tieba_id','=',$id)->delete();
        if ($list) 
        {
            return redirect('/admin/tieba/index')->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }







}
