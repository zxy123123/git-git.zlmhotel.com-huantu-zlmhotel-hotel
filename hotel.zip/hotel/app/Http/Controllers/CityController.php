<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CityController extends Controller
{
    /*
    *城市热门
     */
    public function getIndex(Request $request)
    {
        $list = DB::table('areas')
        ->where('fullname','like','%市')
        ->whereIN('level',[1,2])
        ->where('hot','=',1)
        ->where(function($query) use ($request){
            $query->where('fullname','like','%'.$request->input('keywords').'%');
        })
        ->paginate(6);
        // dd($list);
        return view('city.index',['list'=>$list,'request'=>$request->all()]);
    }

    /*
    *设置城市热门
     */
    public function postSet(Request $request)
    {
        $sheng = $request->sheng;
        $shi = $request->shi;
        $qu = $request->qu;
        // dd($qu);
        if (!empty($sheng)) 
        {
            $data['hot'] = 1;
            $list = DB::table('areas')->where('code','=',$sheng)->update($data);
        }
        if (!empty($shi)) 
        {
            $row['hot'] = 1;
            $one = DB::table('areas')->where('code','=',$shi)->update($row);
            if (!$one) 
            {
                return response()->json(array('msg'=> '3'), 200);
            }
        }
        if (!empty($qu)) 
        {
            $result['hot'] = 1;
            $two = DB::table('areas')->where('code','=',$qu)->update($result);
            if (!$two) 
            {
                return response()->json(array('msg'=> '3'), 200);
            }
        }
        if ($list || $one ||  $two) 
        {
            return response()->json(array('msg'=> '1'), 200);
        }else{
            return response()->json(array('msg'=> '2'), 200);
        }
    }

    /*
    *取消城市热门
     */
    public function postCancel(Request $request)
    {
        $code = $request->code;
        $row['hot'] = 0;
        $list = DB::table('areas')->where('code','=',$code)->update($row);
        $result = DB::table('areas')->where('parent_code','=',$code)->update($row);
        if ($list && $result) 
        {
            return response()->json(array('msg'=>'1'),200);
        }else{
            return response()->json(array('msg'=>'2'),200);
        }
    }

    /*
    *显示城市
     */
    public function getShow(Request $request)
    {
        $list = DB::table('areas')
        ->where('fullname','like','%市')
        ->whereIN('level',[1,2])
        ->where('fronted_show','=',1)
        ->where(function($query) use ($request){
            $query->where('fullname','like','%'.$request->input('keywords').'%');
        })
        ->paginate(6);
        // dd($list);
        return view('city.show',['list'=>$list,'request'=>$request->all()]);
    }

    /*
    *设置显示城市
     */
    public function postSetshow(Request $request)
    {
        $sheng = $request->sheng;
        $shi = $request->shi;
        $qu = $request->qu;
        // dd($qu);
        if (!empty($sheng)) 
        {
            $data['fronted_show'] = 1;
            $list = DB::table('areas')->where('code','=',$sheng)->update($data);
        }
        if (!empty($shi)) 
        {
            $row['fronted_show'] = 1;
            $one = DB::table('areas')->where('code','=',$shi)->update($row);
            if (!$one) 
            {
                return response()->json(array('msg'=> '3'), 200);
            }
        }
        if (!empty($qu)) 
        {
            $result['fronted_show'] = 1;
            $two = DB::table('areas')->where('code','=',$qu)->update($result);
            if (!$two) 
            {
                return response()->json(array('msg'=> '3'), 200);
            }
        }
        if ($list || $one ||  $two) 
        {
            return response()->json(array('msg'=> '1'), 200);
        }else{
            return response()->json(array('msg'=> '2'), 200);
        }
    }

    /*
    *取消显示城市
     */
    public function postCanshow(Request $request)
    {
        $code = $request->code;
        $row['fronted_show'] = 0;
        $list = DB::table('areas')->where('code','=',$code)->update($row);
        $result = DB::table('areas')->where('parent_code','=',$code)->update($row);
        if ($list && $result) 
        {
            return response()->json(array('msg'=>'1'),200);
        }else{
            return response()->json(array('msg'=>'2'),200);
        }
    }






}
