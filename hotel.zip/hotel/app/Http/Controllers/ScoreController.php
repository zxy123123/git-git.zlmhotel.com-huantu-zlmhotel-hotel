<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ScoreController extends Controller
{
    /*
    *积分记录
     */
    public function getIndex()
    {
        $one = DB::table('hotel_admin')->select('hotel_id')->get();
        // var_dump($one);
        $two=[];
        foreach ($one as $key => $value) 
        {
            $two[] = $value['hotel_id'];
        }

        $a = [];
        foreach ($two as $val) 
        {
            $b = [];
            $list = DB::table('hotels')->where('id','=',$val)->select('hotels.name')->first();
            $row = DB::table('orders')->where('hotel_id','=',$val)->count('hotel_id');
            $result = DB::table('score')->where('hotelId','=',$val)->sum('score_num');
            $b['name'] = $list['name'];
            $b['total'] = $row;
            $b['allscore'] = $result;
            $a[] = $b;
        }
        return view('score.index',['list'=>$a]);
    }


}
