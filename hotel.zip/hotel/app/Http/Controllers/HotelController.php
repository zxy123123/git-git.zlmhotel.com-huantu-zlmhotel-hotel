<?php

namespace App\Http\Controllers;

use Image,Log;
use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use zgldh\QiniuStorage\QiniuStorage;

class HotelController extends Controller
{
 
    public function getIndex(Request $request)
    {
                 $res = DB::table('hotels')
                ->join('display_pictures','display_pictures.relate_id','=','hotels.id')
                // ->join('hotel_admin','hotel_admin.hotel_id','=','hotels.id')
                ->where('display_pictures.type','=','hotel')
                ->select('hotels.*','display_pictures.url')
                ->paginate(4);
                // dd($res);
                $list = DB::table('score')
                    ->where('hotelId','=',30)
                    ->sum('score_num');
                // var_dump($list);
        return view('hotel.index',['res'=>$res,'request'=>$request->all()]);
    }

    /*
    *验证码页面
     */
    public function getVode(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $hotelid = DB::table('hotel_admin')
                    ->where('admin_id','=',$admin_id)
                    ->value('hotel_id');
        $list = DB::table('tiebas')
                    ->where('relate_id','=',$hotelid)
                    ->where('type','=','hotel')
                    ->first();

        $time = explode(' ',$list['updated_at']);
        return view('hotel.vode',['list'=>$list,'time'=>$time]);
    }

    /*
    *设置验证码页面
     */
    public function postDocode(Request $request)
    {
        // var_dump($request->all());
        // $this->validate($request,[
        //     'verification_code'=>'required|alpha_num',
        //     ],[
        //     'verification_code.required'=>'验证码不能为空',
        //     'verification_code.alpha_num'=>'格式错误,要数字字母',
        //     ]
        //     );
        $list = $request->except('_token');
        $list['updated_at'] = date('Y-m-d H:i:s');
        $admin_id = $request->session()->get('id');

        $hotelid = DB::table('hotel_admin')
                    ->where('admin_id','=',$admin_id)
                    ->value('hotel_id');
        $res = DB::table('tiebas')
                    ->where('relate_id','=',$hotelid)
                    ->where('type','=','hotel')
                    ->update($list);
        if ($res) 
        {
            return back()->with('success','设置成功');
        }else{
            return back()->with('error','设置失败');
        }
    }




    /**
     * 酒店的编辑页面
     */
    public function getEdit(Request $request)
    {
        $id = $request->id;
        $list = DB::table('hotels')->where('id','=',$id)->first();
        $row = DB::table('hotel_infrastructure')->where('hotel_id','=',$id)->get();
        // var_dump($row);
        $arr = [];
        foreach ($row as $key => $val) 
        {
            $arr[] = $val['infrastructure_id'];
        }
        // var_dump($arr);

        // var_dump($list);
        return view('hotel.edit',['list'=>$list,'arr'=>$arr]);
    }




    /*
    *执行编辑操作
     */
    public function postUpdate(Request $request)
    {
        // dd($request->all());
        $this->validate($request,[
            'name' => 'required',
            'grade' =>'required',
            'phone_number' => 'required|regex:/^[0-9]*$/',
            'longitude' => 'required',
            'latitude'=>'required',
            'email'=>'required',
            'routes'=>'required',
            'introduction'=>'required',
            ],[
            'name.required'=>'酒店名不能为空',
            'grade.required'=>'酒店星级不能为空',
            'phone_number.required'=>'酒店电话不能为空',
            'longitude.required'=>'酒店经度不能为空',
            'latitude.required'=>'酒店纬度不能为空',
            'email.required'=>'酒店邮箱不能为空',
            'routes.required'=>'酒店路线不能为空',
            'introduction.required'=>'酒店简介不能为空',
            ]);
        $data = $request->except(['_token','address1','address2','address3','hotel_id','checkbox']);
        // dd($list);
        if (empty($request->input('address3')) && empty($request->input('address2'))) 
        {
            $data['area_code'] = $request->input('address1');
        }else if(empty($request->input('address3')) && !empty($request->input('address2'))){
            $data['area_code'] = $request->input('address2');
        }else if(!empty($request->input('address3'))){
            $data['area_code'] = $request->input('address3');
        }
        // dd($data);
        $hello = DB::table('areas')->where('code','=',$data['area_code'])->value('id');
        // dd($hello);
        $data['area_id'] = $hello;
        // dd($request->checkbox);
        $bob = DB::table('hotel_infrastructure')->where('hotel_id','=',$request->input('hotel_id'))->delete();
        $arr = $request->checkbox;
        for ($i=0; $i <count($arr); $i++) 
        { 
            $tnt['hotel_id'] = $request->hotel_id;
            $tnt['infrastructure_id'] = $arr[$i];
            $yun = DB::table('hotel_infrastructure')->insert($tnt);
        }
        // dd($data);
        $row = DB::table('hotels')->where('id','=',$request->input('hotel_id'))->update($data);
        // dd($row);
        if ($row) 
        {
            return redirect('/admin/hotel/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }

    }

    /*
    *查询地址
     */
    public function getAddred(Request $request)
    {
        $aa = $request->parent_code;
        if ($aa !=null && $aa != '') 
        {
            $upid = $aa;
        }else{
            $upid = '';
        }
        // $upid = empty($aa)?'':$aa;
        $data = DB::table('areas')->where('parent_code','=',$upid)->get();

         echo json_encode($data); 
            // return response()->json($data, 200);
    }

    /*
    *执行删除操作
     */
    public function getDel(Request $request)
    {
        $id = $request->id;
        $row = DB::table('hotels')->where('id','=',$id)->delete();
        $list = DB::table('hotel_infrastructure')->where('hotel_id','=',$id)->delete();
        $res = DB::table('hotel_admin')->where('hotel_id','=',$id)->delete();
        if ($row && $list && $res) 
        {
            return redirect('/admin/hotel/index')->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }

    /*
    *编辑酒店图片页面
     */
    public function getEditpic()
    {
        return view('hotel.editpic');
    }

    /**
     * 上传文件到七牛
     * @date   2016-11-09T16:58:37+0800
     * @param  Request                  $request [description]
     * @return [type]                            [description]
     */
    public function postUpload(Request $request)
    {
        // 判断是否有文件上传
        if ($request->hasFile('file')) {
            // 获取文件,file对应的是前端表单上传input的name
            $file = $request->file('file');
            // Laravel5.3中多了一个写法
            // $file = $request->file;
            // dd($file);
            // 初始化
            $disk = QiniuStorage::disk('qiniu');

            // 重命名文件
            $name = time().rand();
            $fileName =$name.'.'.$file->getClientOriginalExtension();

            // $fileName = md5($file->getClientOriginalName().time().rand()).'.'.$file->getClientOriginalExtension();

            // 上传到七牛
            $bool = $disk->put('hotel/'.$fileName,$file);
            dd($bool);
            // 判断是否上传成功
            if ($bool) {
                $path = $disk->downloadUrl('hotel/'.$fileName);
                return '上传成功，图片url:'.$path;
            }
            return '上传失败';
        }
        return '没有文件';
    }














}
