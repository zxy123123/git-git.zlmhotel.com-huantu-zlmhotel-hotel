<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class RoomController extends Controller
{
 
    public function getIndex(Request $request)
    {

        $admin_id = $request->session()->get('id');
        $list = DB::table('hotel_admin')->where('admin_id','=',$admin_id)->value('hotel_id');
        $res = DB::table('rooms')
                ->join('display_pictures','display_pictures.relate_id','=','rooms.id')
                ->where('rooms.hotel_id','=',$list)
                ->where('display_pictures.type','=','room')
                ->select('rooms.*','display_pictures.url')
                ->get();
        // var_dump($res);
        return view('room.index',['res'=>$res]);
    }

    /**
     * 房间的添加页面
     */
    public function getAdd(Request $request)
    {
        return view('room.add');
    }

    /**
     * 房间的执行添加操作
     */
    public function postDoadd(Request $request)
    {
        // dd($request->all());
        $list = $request->except('_token');
        $admin_id = $request->session()->get('id');
        $one = DB::table('hotel_admin')->where('admin_id','=',$admin_id)->value('hotel_id');
        $list['hotel_id'] = $one;

       $this->validate($request,[
        'display_name'=>'required',
        'name' =>'required',
        'price'=>'required',
        'count_num'=>'required',
        'area'=>'required',
        'people_num'=>'required',
        'floors'=>'required',
        'breakfast'=>'required',
        'bed_add'=>'required',
        'smoke'=>'required',
        'hot_water'=>'required',
        'air_conditioner'=>'required',
        'internet'=>'required',
        ],[
        'display_name.required'=>'房型展示名称不能为空',
        'name.required'=>'房型英文名不能为空',
        'price.required'=>'单间价格不能为空',
        'count_num.required'=>'总房间数不能为空',
        'area.required'=>'房间面积不能为空',
        'people_num.required'=>'可住人数不能为空',
        'floors.required'=>'房间所在楼层不能为空',
        'breakfast.required'=>'早餐不能为空',
        'bed_add.required'=>'加床不能为空',
        'smoke.required'=>'吸烟不能为空',
        'hot_water.required'=>'热水不能为空',
        'air_conditioner.required'=>'空调不能为空',
        'internet.required'=>'网络情况不能为空',
        ]);
       $res = DB::table('rooms')->insert($list);
       if ($res) 
       {
           return redirect('admin/room/index')->with('success','添加成功');
       }else{
        return back()->with('error','添加失败');
       }
    }

    /**
     * 房间的编辑页面
     */
    public function getEdit(Request $request)
    {
        $id = $request->id;
        $list = DB::table('rooms')
                ->where('id','=',$id)
                ->first();
        // var_dump($list);
        return view('room.edit',['list'=>$list]);
    }

    /**
     * 房间满了后的关房操作
     */
    public function getFull(Request $request)
    {
        $id = $request->id;
        $data['full'] = '0';
        $row['full'] = '1';
        $result = DB::table('rooms')
                ->where('id','=',$id)
                ->value('full');
        if ($result == '0') 
        {
            $list = DB::table('rooms')
                ->where('id','=',$id)
                ->update($row);
        }else{
            $list = DB::table('rooms')
                ->where('id','=',$id)
                ->update($data);
        }
        if ($list) 
        {
             return response()->json(array('msg'=>'1'),200);
        }else{
             return response()->json(array('msg'=>'2'),200);
        }

    }

    /**
     * 房间的执行编辑操作
     */
    public function postDoedit(Request $request)
    {
      $this->validate($request,[
        'display_name'=>'required',
        'name' =>'required',
        'price'=>'required',
        'count_num'=>'required',
        'area'=>'required',
        'people_num'=>'required',
        'floors'=>'required',
        'breakfast'=>'required',
        'bed_add'=>'required',
        'smoke'=>'required',
        'hot_water'=>'required',
        'air_conditioner'=>'required',
        'internet'=>'required',
        ],[
        'display_name.required'=>'房型展示名称不能为空',
        'name.required'=>'房型英文名不能为空',
        'price.required'=>'单间价格不能为空',
        'count_num.required'=>'总房间数不能为空',
        'area.required'=>'房间面积不能为空',
        'people_num.required'=>'可住人数不能为空',
        'floors.required'=>'房间所在楼层不能为空',
        'breakfast.required'=>'早餐不能为空',
        'bed_add.required'=>'加床不能为空',
        'smoke.required'=>'吸烟不能为空',
        'hot_water.required'=>'热水不能为空',
        'air_conditioner.required'=>'空调不能为空',
        'internet.required'=>'网络情况不能为空',
        ]);

      $data = $request->except('_token','id');
      $res = DB::table('rooms')->where('id','=',$request->id)->update($data);
       if ($res) 
       {
           return redirect('admin/room/index')->with('success','修改成功');
       }else{
        return back()->with('error','修改失败');
       }
    }












}
