<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class GoodsController extends Controller
{
    /**
     * 商品管理
     */
    public function getIndex(Request $request)
    {
        $list = DB::table('goods as g')
                    ->join('categroy as c','c.id', '=','g.cate_id')
                    ->join('image as i','g.id','=','i.goods_id')
                    ->select('g.id as gid','g.gname','g.id as gid','c.cname','g.price','g.stock','i.iname','g.msg')
                    ->where(function($query) use ($request){
                        $query->where('g.gname','like','%'.$request->input('keywords').'%');
                    })
                    ->paginate(6);

        // var_dump($list);
        return view('goods.index',['list'=>$list,'request'=>$request->all()]);
    }

    /**
     * 获取分类下所有的分类 按照顺序来获取
     */
    public static function getCates()
    {
        $res = DB::table('categroy')
                ->select(DB::raw('id,path,pid,cname,concat(path,id) as paths'))//用原生SQL语句就用DB::raw
                ->orderBy('paths')
                ->get();
        //调整分类名称
        foreach ($res as $key => $val) 
        {
            //拆分数组
            $tmp = explode(',', $val['path']);
            $len = count($tmp) - 1;
            //修改分类名称
            $res[$key]['cname'] = str_repeat('|----', $len).$val['cname'];
            // var_dump($len);

        }
        // var_dump($res);die;
        return $res;
    } 



    /**
     * 商品信息编辑页面
     */
    public function getEdit(Request $request)
    {
        $id = $request->id;
        $list = DB::table('goods as g')
                    ->join('categroy as c','c.id', '=','g.cate_id')
                    ->join('image as i','g.id','=','i.goods_id')
                    ->select('g.id as gid','g.gname','g.id as gid','c.cname','g.price','g.stock','i.iname','g.msg','g.cate_id as gcd')
                    ->where('g.id','=',$id)
                    ->first();
        $cate = self::getcates();
        return view('goods.edit',['list'=>$list,'cate'=>$cate]);
    }

    /**
     * 执行商品信息编辑
     */
    public function postUpdate(Request $request)
    {
        $data = $request->except(['_token','goodsid']);
        $res = DB::table('goods')->where('id','=',$request->goodsid)->update($data);
        if ($res) 
        {
            return redirect('admin/goods/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
    }

    /**
     * 商品添加页面
     */
    public function getAdd()
    {
        $cate = self::getcates();
        return view('goods.add',['cate'=>$cate]);
    }

    /**
     * 执行商品添加操作
     */
    public function postInsert(Request $request)
    {
        // var_dump($request->all());
        $data = $request->except(['_token']);
        $res  = DB::table('goods')->insertGetId($data);

        if ($res) 
        {
            $row['iname'] = '11';
            $row['goods_id'] = $res;
            $result = DB::table('image')->insert($row);
            if ($result) 
            {
                return redirect('/admin/goods/index')->with('success','添加成功');
            }else{
                return back()->with('error','添加失败');
            }
        }else{
            return back()->with('error','添加失败');
        }
        // var_dump($data);
    }

    /**
     * 商品订单
     */
    public function getOrder(Request $request)
    {
        $list = DB::table('goodsorder as go')
                  ->join('order_goods as og','og.order_id','=','go.id')
                  ->join('goods as g','g.id','=','og.goods_id')
                ->join('image as i','i.goods_id','=','g.id')
                ->select('g.gname','i.iname','go.lname','go.address','go.phone','go.allprice','og.price','og.qty','go.ordernum','go.ordernum')
                ->where(function($query) use ($request){
                    $query->where('go.phone','like','%'.$request->input('keywords').'%');
                })
                ->paginate(7);
                // ->get();
                // var_dump($list);
        return view('goods.order',['list'=>$list,'request'=>$request->all()]);
    }





}
