<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    /**
     * 管理员添加页面显示
     */
    public function getAdd()
    {
        return view('user.add');
    }

    /**
     * 执行添加操作
     */
    public function postInsert(Request $request)
    {
        //手动验证
        // if (!$request->input('username')) 
        // {
        //     return back()->with('error','用户名不能为空');
        // }

        //laravel内置的表单验证
        $this->validate($request, [
            'name' => 'required',
            'hotelname' =>'required',
            'password' => 'required|alpha_num',
            'admin_telephone' => 'required',
            ],[
            'name.required' => '用户名不能为空',
            'hotelname.required' => '酒店名不能为空',
            'password.required' => '密码不能为空',
            'password.alpha_num' => '密码格式错误,要数字字母',
            'admin_telephone.required' => '酒店电话不能为空',
        ]);

        //执行数据的添加操作
        
        //第一种添加方式:拼接参数
        // $data['name'] = $request->input('username');
        // $data['hotelname'] = $request->input('hotelname');
        // $data['password'] = $request->input('pwd');
        // $data['phone'] = $request->input('phone');
        // $res = DB::table('hotel_admin')->insert($data);

        //第二种:提取部分参数
        $row['name'] = $request->hotelname;
        $result = DB::table('hotels')->insertGetId($row);
        // dd($result);
        if ($result) 
        {
            $data = $request->only(['name','admin_telephone','password']);
            $data['password'] = Hash::make($data['password']);
            $data['hotel_id'] = $result;
            $res = DB::table('hotel_admin')->insert($data);
            if ($res) 
            {
                return redirect('admin/user/index')->with('success','添加成功');
            }else{
                return back()->with('error','添加失败');
            }
        }else{
             return back()->with('error','添加失败,请联系管理员');
        }





    }

    public function getIndex(Request $request)
    {
        //读取用户数据并分页 复杂方法
        // if ($request->input('keywords')) 
        // {
        //     $keywords = $request->input('keywords');
        //     $users = DB::table('hotel_admin')
        //     ->where('name','like','%'.$keywords.'%')
        //     ->paginate(10);
        // }else{
        //     $users = DB::table('hotel_admin')->paginate(10);
        // }
        // dd($request->all());
        // 简便方法
        $users = DB::table('hotel_admin as ha')
            ->join('hotels as h','h.id','=','ha.hotel_id')
            ->select('ha.admin_id','h.name as hn','ha.admin_telephone','ha.name as han')
            ->where(function($query) use ($request) {
                $query->where('ha.name','like','%'.$request->input('keywords').'%');
            })
            ->paginate(6);
        //分配到模板并显示
        return view('user.index',['users'=>$users,'request'=>$request->all()]);
        
    }

    /**
     * 管理员修改
     */
    public function getEdit($admin_id)
    {
                $users = DB::table('hotel_admin as ha')
            ->join('hotels as h','h.id','=','ha.hotel_id')
            ->select('ha.admin_id','h.name as hn','ha.admin_telephone','ha.name as han','ha.hotel_id')
            ->first();
            // dd($users);

        //读取数据库

        //显示模板
        return view('user.edit',['users'=>$users]);
    }

    /**
     * 执行修改
     */
    public function postUpdate(Request $request)
    {
        // dd($request->all());
        $this->validate($request, [
            'name' => 'required',
            'hotelname' =>'required',
            'admin_telephone' => 'required',
            ],[
            'name.required' => '用户名不能为空',
            'hotelname.required' => '酒店名不能为空',
            'admin_telephone.required' => '酒店电话不能为空',
        ]);

        //获取参数
        $data = $request->only('admin_id','name','admin_telephone');
        $list['name'] = $request->hotelname;
        $hotel_id = $request->hotel_id;
        $result = DB::table('hotels')
                    ->where('id','=',$hotel_id)
                    ->update($list);
                    // dd($result);
        //开始更新
        $res = DB::table('hotel_admin')->where('admin_id','=',$request->input('admin_id'))->update($data);
        //判断
        if ($res) 
        {
            return redirect('/admin/user/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
        
    }

    /**
     * 删除管理员
     */
    public function getDelete($id)
    {
        //删除
        $res = DB::table('hotel_admin')->where('admin_id','=',$id)->delete();
        if ($res) 
        {
            return redirect('/admin/user/index')->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }


}
