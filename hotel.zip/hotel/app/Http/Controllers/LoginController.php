<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Hash;
use Crypt;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;

class LoginController extends Controller
{
    /**
     * 用户后台登录页面显示
     */
    public function login()
    {

        return view('admin.login');
    }

    /**
     * 用户的登录操作
     */
    public function dologin(LoginRequest $request)
    {
        // dd($request->all());
        // dd($request->all());
        //获取用户信息
        $user = DB::table('hotel_admin')
                ->where('name',$request->input('username'))
                ->first();
                // dd($user);
        //检测密码是否一致
        if (Hash::check($request->input('password'),$user['password'])) 
        {
            //让用户登录
            session([
                'id'=>$user['admin_id'],
                'name'=>$user['name'],
                'permission'=>$user['permission']
                ]);
            // dd($request->session);
            //记住我的操作
            if ($request->input('remember')) 
            {
                $str = 'admin|admin';
                //加密
                $auth_user = Crypt::encrypt($str);
                //写入cookie
                \Cookie::queue('auth_user',$auth_user,60*24*7);  //单位为分钟
            }

            return redirect('/admin')->with('success','登录成功');
        }else{
            return back()->with('error','登录失败'); 
        }
    }

    public function loginout()
    {
        session::forget("id");
    }


}
