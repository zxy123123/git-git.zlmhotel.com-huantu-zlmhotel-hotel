<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class OrderController extends Controller
{
    /**
     * 所有订单显示页
     */
    public function getIndex(Request $request)
    {
        $order = DB::table('orders as o')
                    ->join('user_usual_infos AS ui ','ui.id','=','o.usual_user_info_id')
                    ->join('users AS u','o.user_id','=','u.id')
                    ->join('hotels AS h','h.id','=','o.hotel_id')
                    ->join('rooms AS r','r.id','=','o.room_id')
                    ->where('ui.name','like','%'.$request->input('keywords').'%')
                    ->select('o.id as oid','ui.name as uin','ui.phone as up','h.name as hn','r.display_name as rdn','r.price as rp','o.room_num as orn','o.start_time as ost','o.payment_status as ops','o.payment_method as opm','o.order_status as oos','o.latest_arrive_time as olat','o.open_id as ooi','o.special_requirement as osr','o.remark as ork','u.score','o.end_time as oed','o.check_in')
                    ->paginate(4);
        // dd($order);

        return view('order.index',['order'=>$order,'request'=>$request->all()]);
    }

    /**
     * 修改备注
    */
    public function postEditmask(Request $request)
    {
        // var_dump($request->all());
        $this->validate($request,[
            'remark' => 'required',
            ],[
            'remark.required' => '请输入备注',
            ]);
        //获取参数
        $data = $request->only('remark','id');
        $res = DB::table('orders')->where('id','=',$request->input('id'))->update($data);
        if ($res) 
        {
            return redirect('/admin/order/index')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
    }

    /**
     * 确认入住
     */
    public function postQueren(Request $request)
    {
        $data = $request->id;
        $res = DB::table('orders')->where('id','=',$data)->first();
        if ($res['check_in'] == 0) 
        {
            $list['check_in'] = 1;
            $row = DB::table('orders')->where('id','=',$data)->update($list);
            if ($row) 
            {
                return response()->json(array('msg'=> '1'), 200);
            }else{
                return response()->json(array('msg'=> '2'), 200);
            }
        }else{
            return response()->json(array('msg'=> '0'), 200);
        }
    }

    /**
     * 删除订单
     */
    public function getDel(Request $request)
    {
        $data = $request->id;
        $res = DB::table('orders')->where('id','=',$data)->first();
        if ($res['order_status'] == 'finsh') 
        {
            $row = DB::table('orders')->where('id','=',$data)->delete();
            if ($row) 
            {
                return back()->with('success','删除成功');
            }else{
                return back()->with('error','删除失败');
            }
        }else{
            return back()->with('error','订单未完成无法删除');
        }
    }

    /**
     * 批量删除订单
     */
    public function postAlldel(Request $request)
    {
        $list = $request->all();
        foreach ($list as $key => $val) 
        {
            foreach ($val as $k=> $v) 
            {
                $list = DB::table('orders')
                        ->where('id','=',$v)
                        ->delete();
                if ($list) 
                {
                    return response()->json(array('msg'=> '1'), 200);
                }else{
                    return response()->json(array('msg'=> '2'), 200);
                }
            }
        }
    }




    /**
     * 未入住订单
     * 
     */
    public function getOnorder(Request $request)
    {
        $order = DB::table('orders as o')
                    ->join('user_usual_infos AS ui ','ui.id','=','o.usual_user_info_id')
                    ->join('users AS u','o.user_id','=','u.id')
                    ->join('hotels AS h','h.id','=','o.hotel_id')
                    ->join('rooms AS r','r.id','=','o.room_id')
                    ->where('check_in',0)->where('ui.name','like','%'.$request->input('keywords').'%')
                    ->select('o.id as oid','ui.name as uin','ui.phone as up','h.name as hn','r.display_name as rdn','r.price as rp','o.room_num as orn','o.start_time as ost','o.payment_status as ops','o.payment_method as opm','o.order_status as oos','o.latest_arrive_time as olat','o.open_id as ooi','o.special_requirement as osr','o.remark as ork')
                    ->paginate(4);
                    // dd($order);
        return view('order.onorder',['order'=>$order,'request'=>$request->all()]);
    }

    /**
     * 未入住订单的确认入住操作
     */
    public function postSurecheck(Request $request)
    {
        $id = $request->id;
        $two = DB::table('orders')->where('id','=',$id)->select('user_id','hotel_id')->first();//查询会员的id和入住酒店的id
        $wubai = DB::table('hotel_admin')->where('hotel_id','=',$two['hotel_id'])->select('credit')->first();//查询入住酒店有多少积分
        if ($wubai['credit'] <= 500) 
        {
            return response()->json(array('msg'=> '3'), 200);//入住酒店积分少于500,不能确认入住
        }else{
            $tt = $two['user_id'];
            $three = DB::table('users')->where('id','=',$tt)->select('score','hotel_id')->first();//查询会员积分和所属酒店的id
            if ($two['hotel_id'] == $three['hotel_id']) //如果相等说明A会员在A酒店
            {
                $aa['score'] = $three['score'] + 10;//A会员积分加10
                $bb = DB::table('users')->where('id','=',$tt)->update($aa);
                $zhifu['payment_status'] = 'paid';//会员入住后把支付状态改成支付成功
                $zhifucg = DB::table('orders')->where('id','=',$id)->update($zhifu);
                $cc = DB::table('hotel_admin')->where('hotel_id','=',$three['hotel_id'])->select('credit')->first();//查询所属酒店的积分
                $dd['credit'] = $cc['credit'] - 10;//把酒店积分减去10;
                $ee = DB::table('hotel_admin')->where('hotel_id','=',$three['hotel_id'])->update($dd);

            }else{
 //如果不相等说明A会员在B酒店,B酒店减30个积分,a酒店加10积分,不管A会员在哪个酒店入住都会加10积分
                $ff['score'] = $three['score'] + 10;//那么A会员积分加10

                $gg = DB::table('users')->where('id','=', $two['user_id'])->update($ff);
                
                $zhifu['payment_status'] = 'paid';
                $zhifucg = DB::table('orders')->where('id','=',$id)->update($zhifu);
                $hh = DB::table('hotel_admin')->where('hotel_id','=',$three['hotel_id'])->select('credit')->first();//查询会员所属酒店的积分然后加10
                $ii['credit'] = $hh['credit'] - 30;
                $jj = DB::table('hotel_admin')->where('hotel_id','=',$three['hotel_id'])->update($ii);
                $kk = DB::table('hotel_admin')->where('hotel_id','=',$two['hotel_id'])->select('credit')->first();//查询会员入住酒店的积分然后减30
                $ll['credit'] = $kk['credit']-30;
                $mm = DB::table('hotel_admin')->where('hotel_id','=',$two['hotel_id'])->update($ll);
                //往score表增加记录
                $nn['score_num'] = 30;
                $nn['hotelId'] = $three['hotel_id'];
                $nn['contributor'] = $two['hotel_id'];
                $nn['score_date'] = date('Y-m-d H:i:s');
                $oo = DB::table('score')->insert($nn);
            }
        }
        $data['check_in'] = 1;
        $row = DB::table('orders')->where('id','=',$id)->update($data);
        if ($row) 
        {
            return response()->json(array('msg'=>'1'),200);
        }else{
            return response()->json(array('msg'=>'2'),200);
        }
    }

    /**
     * 未入住订单删除操作
     */
    public function getOndel(Request $request)
    {
        $id = $request->id;
        $res = DB::table('orders')
                ->where('id','=',$id)
                ->delete();
        if($res) 
        {
            return back()->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }



    /**
     * 历史订单
     */
    public function getPayorder(Request $request)
    {
        $order = DB::table('orders as o')
                    ->join('user_usual_infos AS ui ','ui.id','=','o.usual_user_info_id')
                    ->join('users AS u','o.user_id','=','u.id')
                    ->join('hotels AS h','h.id','=','o.hotel_id')
                    ->join('rooms AS r','r.id','=','o.room_id')
                    ->where('check_in',1)->where('ui.name','like','%'.$request->input('keywords').'%')
                    ->select('o.id as oid','ui.name as uin','ui.phone as up','h.name as hn','r.display_name as rdn','r.price as rp','o.room_num as orn','o.start_time as ost','o.payment_status as ops','o.payment_method as opm','o.order_status as oos','o.latest_arrive_time as olat','o.open_id as ooi','o.special_requirement as osr','o.remark as ork')
                    ->paginate(4);

        return view('order.payorder',['order'=>$order,'request'=>$request->all()]);
    }

    /**
     * 退款订单
     */
    public function getRefund(Request $request)
    {
        $order = DB::table('refunds AS r')
                    ->join('orders AS o','r.order_id','=','o.id')
                    ->join('user_usual_infos AS ui','ui.id','=','o.usual_user_info_id')
                    ->where('ui.name','like','%'.$request->input('keywords').'%')
                    ->select('r.*','ui.name as uname','ui.phone as up')
                    ->paginate(4);
                    // dd($order);
        return view('order.refund',['order'=>$order,'request'=>$request->all()]);
        
    }

    /**
     * 退款订单的同意退款操作
     */
    public function postAgree(Request $request)
    {
        $id = $request->id;
        // $list = DB::table('refunds')->where('id','=',$id)->value('order_id');//查单条的值
        $list = DB::table('refunds')->where('id','=',$id)->select('order_id', 'status')->first();//查询用户有无申请退款
        // dd($list);
        $row = DB::table('orders')->where('id','=',$list['order_id'])->select('order_status', 'refund')->first();

        // dd($row);
        if ($row['order_status'] == 'success' && $row['refund'] == 1 && $list['status'] == 'apply') 
        {
            $data['status'] = 'agree';
            $three = DB::table('refunds')->where('id','=',$id)->update($data);
            if ($three) 
            {
                $pup['refund_id'] = $id;
                $pup['status'] = 'agree';
                $pup['created_at'] = date('Y-m-d H:i:s');
                $pup['updated_at'] = date('Y-m-d H:i:s');
                $bob = DB::table('refund_records')->insert($pup);
                return response()->json(array('msg'=> '1'), 200);
            }else{
                return response()->json(array('msg'=> '2'), 200);//更新失败
            }
        }else{
            return response()->json(array('msg'=> '3'), 200);//订单未完成不能退款
        }
    }

    /**
     * 退款订单的拒绝退款操作
     */
    public function postRefuse(Request $request)
    {
        $id = $request->id;
        $one = DB::table('refunds')->where('id','=',$id)->value('status');
        // dd($one);
        if ($one !== 'apply') 
        {
            return response()->json(array('msg'=> '3'), 200);//非请求退款状态无法拒绝
        }else{
            $data['status'] = 'reject';
            $two = DB::table('refunds')->where('id','=',$id)->update($data);
            if ($two) 
            {
                $pup['refund_id'] = $id;
                $pup['status'] = 'reject';
                $pup['created_at'] = date('Y-m-d H:i:s');
                $pup['updated_at'] = date('Y-m-d H:i:s');
                $bob = DB::table('refund_records')->insert($pup);
                return response()->json(array('msg'=>'1'),200);
            }else{
                return response()->json(array('msg'=>'2'),200);
            }
        }
    }

    /**
     * 退款订单的退款完成操作
     */
    public function postFinish(Request $request)
    {
        $id = $request->id;
        $one = DB::table('refunds')->where('id','=',$id)->value('status');
        if ($one !== 'agree') 
        {
            return response()->json(array('msg'=>'3'),200);
        }else{
            $data['status'] = 'refund';
            $two = DB::table('refunds')->where('id','=',$id)->update($data);
            if ($two) 
            {
                $pup['refund_id'] = $id;
                $pup['status'] = 'refund';
                $pup['created_at'] = date('Y-m-d H:i:s');
                $pup['updated_at'] = date('Y-m-d H:i:s');
                $bob = DB::table('refund_records')->insert($pup);
                return response()->json(array('msg'=>'1'),200);
            }else{
                return response()->json(array('msg'=>'2'),200);//更新失败
            }
        }
    }

    /**
     * 退款订单的修改备注操作
     */
    public function postEdmask(Request $request)
    {
        $this->validate($request,[
            'remark' => 'required',
            ],[
            'remark.required' => '请输入备注',
            ]);
        //获取参数
        $data = $request->only('remark','id');
        $res = DB::table('refunds')->where('id','=',$request->input('id'))->update($data);
        if ($res) 
        {
            return redirect('/admin/order/refund')->with('success','修改成功');
        }else{
            return back()->with('error','修改失败');
        }
    }










}
