<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class StoreController extends Controller
{
    /**
     * 商品管理
     */
    public function getIndex(Request $request)
    {
        $list = DB::table('goods as g')
                    ->join('image as i','i.goods_id','=','g.id')
                    ->select('g.gname','g.id as gid','i.iname')
                    ->get();

        // var_dump($list);
        return view('store.index',['list'=>$list]);
    }

    /**
     * 商品详情
     */
    public function getGoodsdetail(Request $request)
    {
        // var_dump($request->session());
        $id = $request->id;
        $list = DB::table('goods as g')
                ->join('image as i','i.goods_id','=','g.id')
                ->where('g.id','=',$id)
                ->first();
                // var_dump($list);
        return view('store.goodsdetail',['list'=>$list]);
    }

    /**
     * 购物车页面
     */
    public function getShopcart(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $list = DB::table('shopcart')
                ->where('admin_id','=',$admin_id)
                ->get();
                $sum =0;
        foreach ($list as $key => $val) 
        {
            $sum +=$val['allprice'];
        }
        return view('store.shopcart',['list'=>$list,'sum'=>$sum]);
    }

    /**
     * 加入购物车操作
     */
    public function getCartdo(Request $request)
    {
        // var_dump($request->all());
        $goods_id = $request->goods_id;
        $admin_id = $request->admin_id;
        $qty = $request->qty;
        $sql = DB::table('goods')
                ->where('id','=',$goods_id)
                ->select('stock','gname','price','msg')
                ->first();
        $iname = DB::table('image')
                ->where('goods_id','=',$goods_id)
                ->value('iname');
        // var_dump($iname);
        $gname = $sql['gname'];
        $price = $sql['price'];
        $stock = $sql['stock'];
        $msg = $sql['msg'];
        if ($qty > $stock) 
        {
            return back()->with('error','库存不足');
            exit;
        }
        if (($request->b) == 'add') 
        {
            $list = DB::table('shopcart')
                    ->where('admin_id','=',$admin_id)
                    ->select('admin_id')
                    ->first();
                    // var_dump($list);/
            if (empty($list)) 
            {
                $data['admin_id'] = $admin_id;
                $data['goods_id'] = $goods_id;
                $data['gname'] = $gname;
                $data['iname'] = $iname;
                $data['price'] = $price;
                $data['qty'] = $qty;
                $data['allprice'] = $price*$qty;
                $data['msg'] = $msg;
                $res = DB::table('shopcart')->insert($data);
                $result = DB::table('goods')->where('id','=',$goods_id)->value('stock');
                $row['stock'] = $result - $qty;
                $jack = DB::table('goods')->where('id','=',$goods_id)->update($row);
                if ($res && $jack) 
                {
                    return back()->with('success','已加入购物车');
                }else{
                    return back()->with('error','加入购物车失败,请联系管理员');
                }
            }else{
                $three = DB::table('shopcart')
                        ->where('goods_id','=',$goods_id)
                        ->select('goods_id','qty','price')
                        ->first();
                    if (empty($three)) 
                    {
                        $data['admin_id'] = $admin_id;
                        $data['goods_id'] = $goods_id;
                        $data['gname'] = $gname;
                        $data['iname'] = $iname;
                        $data['price'] = $price;
                        $data['qty'] = $qty;
                        $data['allprice'] = $price*$qty;
                        $data['msg'] = $msg;
                        $res = DB::table('shopcart')->insert($data);
                        $hub['stock'] = $stock - $qty;
                        $ser = DB::table('goods')
                                ->where('id','=',$goods_id)
                                ->update($hub);

                        if ($res && $ser) 
                        {
                            return back()->with('success','已加入购物车');
                        }else{
                            return back()->with('error','加入购物车失败,请联系管理员');
                        }
                    }else{
                        $data['qty'] = $three['qty'] + $qty;
                        $data['allprice'] = $three['price'] *($three['qty'] + $qty);
                        $res = DB::table('shopcart')
                                ->where('goods_id','=',$goods_id)
                                ->update($data);
                         $hub['stock'] = $stock - $qty;
                        $ser = DB::table('goods')
                                ->where('id','=',$goods_id)
                                ->update($hub);

                        if ($res && $ser) 
                        {
                            return back()->with('success','已加入购物车');
                        }else{
                            return back()->with('error','加入购物车失败,请联系管理员');
                        }
                    }
            }
        }else if(($request->b) == 'buy'){
            $list = DB::table('shopcart')
                    ->where('admin_id','=',$admin_id)
                    ->select('admin_id')
                    ->first();
                    // var_dump($list);/
            if (empty($list)) 
            {
                $data['admin_id'] = $admin_id;
                $data['goods_id'] = $goods_id;
                $data['gname'] = $gname;
                $data['iname'] = $iname;
                $data['price'] = $price;
                $data['qty'] = $qty;
                $data['allprice'] = $price*$qty;
                $data['msg'] = $msg;
                $res = DB::table('shopcart')->insert($data);
                $result = DB::table('goods')->where('id','=',$goods_id)->value('stock');
                $row['stock'] = $result - $qty;
                $jack = DB::table('goods')->where('id','=',$goods_id)->update($row);
                if ($res && $jack) 
                {
                    return redirect('/admin/store/shopcart')->with('success','请在购物车结算');
                }else{
                    return back()->with('error','购买失败,请联系管理员');
                }
            }else{
                $three = DB::table('shopcart')
                        ->where('goods_id','=',$goods_id)
                        ->select('goods_id','qty','price')
                        ->first();
                    if (empty($three)) 
                    {
                        $data['admin_id'] = $admin_id;
                        $data['goods_id'] = $goods_id;
                        $data['gname'] = $gname;
                        $data['iname'] = $iname;
                        $data['price'] = $price;
                        $data['qty'] = $qty;
                        $data['allprice'] = $price*$qty;
                        $data['msg'] = $msg;
                        $res = DB::table('shopcart')->insert($data);
                        $hub['stock'] = $stock - $qty;
                        $ser = DB::table('goods')
                                ->where('id','=',$goods_id)
                                ->update($hub);

                        if ($res && $ser) 
                        {
                            return redirect('/admin/store/shopcart')->with('success','请在购物车结算');
                        }else{
                            return back()->with('error','购买失败,请联系管理员');
                        }
                    }else{
                        $data['qty'] = $three['qty'] + $qty;
                        $data['allprice'] = $three['price'] *($three['qty'] + $qty);
                        $res = DB::table('shopcart')
                                ->where('goods_id','=',$goods_id)
                                ->update($data);
                         $hub['stock'] = $stock - $qty;
                        $ser = DB::table('goods')
                                ->where('id','=',$goods_id)
                                ->update($hub);

                        if ($res && $ser) 
                        {
                            return redirect('/admin/store/shopcart')->with('success','请在购物车结算');
                        }else{
                            return back()->with('error','购买失败,请联系管理员');
                        }
                    }
            }
            }

    }

    /**
     * 删除购物车某样物品操作
     */
    public function getDel(Request $request)
    {
        $id = $request->id;
        $qty = $request->qty;
        $list = DB::table('shopcart')
                ->where('goods_id','=',$id)
                ->delete();
        $res = DB::table('goods')
                ->where('id','=',$id)
                ->value('stock');
        $data['stock'] = $res + $qty;
        $row = DB::table('goods')->where('id','=',$id)->update($data);
        if ($list && $row) 
        {
            return back()->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }

    /**
     * 删除全部购物车操作
     */
    public function getAlldel(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $list = DB::table('shopcart')
                    ->where('admin_id','=',$admin_id)
                    ->select('goods_id','qty')
                    ->get();
        // var_dump($list);
        foreach ($list as $key => $val) 
        {
            // var_dump($val['goods_id']);
            $res = DB::table('goods')->where('id','=',$val['goods_id'])->get();
            $data['stock'] = $res[0]['stock'] + $val['qty'];
            $run = DB::table('goods')->where('id','=',$val['goods_id'])->update($data);
            $bob = DB::table('shopcart')->where('admin_id','=',$admin_id)->delete();
            if ($run && $bob) 
            {
                return back()->with('success','清空成功');
            }else{
                return back()->with('error','清空失败,请联系管理员');
            }
            // var_dump($data);
        }
                    // var_dump($list);
    }

    /**
     * 形成订单页面
     */
    public function getDobuy(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $list = DB::table('address')
                ->where('admin_id','=',$admin_id)
                ->where('operate','=',2)
                ->first();
        $goods_id = $request->id;
        if (empty($goods_id)) 
        {
            $row = DB::table('shopcart')
                    ->where('admin_id','=',$admin_id)
                    ->get();
        }else{
            $row = DB::table('shopcart')
                    ->where('goods_id','=',$goods_id)
                    ->get();
        }

        $sum =0;
        foreach ($row as $key => $val) 
        {
            $sum +=$val['allprice'];
        }

            // var_dump($row);
        return view('store.dobuy',['list'=>$list,'row'=>$row,'sum'=>$sum]);
    }

    /**
     * 收货地址页面
     */
    public function getAddress(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $list = DB::table('address')
            ->where('admin_id','=',$admin_id)
            ->where(function($query) use ($request){
                $query->where('address','like','%'.$request->input('keywords').'%');
            })
            ->paginate(6);
        return view('store.address',['list'=>$list,'request'=>$request->all()]);
    }

    /**
     * 收货地址页面
     */
    public function getMo(Request $request)
    {
        $id = $request->id;
        $data['operate'] = '1';
        $row['operate'] = '2';
        $list = DB::table('address')
                ->where('id','=',$id)
                ->update($row);
        $result = DB::table('address')
                ->where('id','<>',$id)
                ->update($data);
        if ($list && $result) 
        {
            return response()->json(array('msg'=>'1'),200);
        }
    }

    /**
     * 收货地址页面
     */
    public function getDeladd(Request $request)
    {
        $id = $request->id;
        $list = DB::table('address')
                ->where('id','=',$id)
                ->where('operate','=','1')
                ->delete();
        if ($list) 
        {
            return back()->with('success','删除成功');
        }else{
            return back()->with('error','删除失败');
        }
    }

    /**
     * 添加收货地址
     */
    public function postAddaddress(Request $request)
    {
        $data = $request->except('_token');
        $admin_id = $request->session()->get('id');
        $data['admin_id'] = $admin_id;
        $list = DB::table('address')->insert($data);
        if ($list) 
        {
            return back()->with('success','添加成功');
        }else{
            return back()->with('error','添加失败,请联系管理员');
        }
    }

    /**
     * 提交订单
     */
    public function postSureorder(Request $request)
    {
        $allprice = $request->allprice;
        $admin_id = $request->session()->get('id');
        if (empty($allprice)) 
        {
            return back()->with('error','请购买商品后再提交');
            exit;
        }
        $list = DB::table('address')
                ->where('operate','=',2)
                ->where('admin_id','=',$admin_id)
                ->first();
        $data['admin_id'] = $admin_id;
        $data['ordernum'] = date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
        $data['lname'] = $list['linkman'];
        $data['phone'] = $list['phone'];
        $data['address'] = $list['address'];
        $data['allprice'] = $allprice;
        $res = DB::table('goodsorder')->insert($data);
        $result = DB::table('shopcart')
                ->where('admin_id','=',$admin_id)
                ->delete();
        if ($res && $result)  
        {
            return redirect('admin/store/order')->with('success','已生成订单');
        }else{
            return back()->with('error','提交失败,请联系管理员');
        }
    }












    /**
     * 我的订单
     */
    public function getOrder(Request $request)
    {
        $admin_id = $request->session()->get('id');
        $list = DB::table('goodsorder as go')
                  ->join('order_goods as og','og.order_id','=','go.id')
                  ->join('goods as g','g.id','=','og.goods_id')
                ->join('image as i','i.goods_id','=','g.id')
                ->where('admin_id','=',$admin_id)
                ->orderBy('go.id', 'desc')
                ->select('g.gname','i.iname','go.lname','go.address','go.phone','go.allprice','og.price','og.qty','go.ordernum','go.status')
                ->where(function($query) use ($request){
                    $query->where('go.phone','like','%'.$request->input('keywords').'%');
                })
                ->paginate(7);
               
        return view('store.order',['list'=>$list,'request'=>$request->all()]);
    }







}
