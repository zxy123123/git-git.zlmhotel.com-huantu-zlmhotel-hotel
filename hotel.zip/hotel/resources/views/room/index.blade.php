@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        房间管理
        <small>
            <i class="icon-double-angle-right"></i>
             房间管理
        </small>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>房间名称</th>
                    <th>房间价格</th>
                    <th>总房间数</th>
                    <th>房间面积</th>
                    <th>可住人数</th>
                    <th>房间所在楼层</th>
                    <th>有无早餐</th>
                    <th>可否加床</th>
                    <th>加床价格</th>
                    <th>单床大小</th>
                    <th>可否吸烟</th>
                    <th>是否有热水</th>
                    <th>是否有空调</th>
                    <th>网络情况</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
@foreach($res as $v)
                <tr>
                    <td>{{$v['id']}}</td>
                    <td>{{$v['display_name']}} </td>
                    <td>{{$v['price']}}</td>
                    <td>{{$v['count_num']}}</td>
                    <td>{{$v['area']}}</td>
                    <td>{{$v['people_num']}}</td>
                    <td>{{$v['floors']}}</td>
                    <td>
                    @if($v['breakfast'] == '0')无
                    @else有
                    @endif
                    </td>
                    <td>
                    @if($v['bed_add'] == '0')不能
                    @else能
                    @endif
                    </td>
                    <td>{{$v['bed_add_price']}}</td>
                    <td>{{$v['bed_area']}}</td>
                    <td>
                    @if($v['smoke'] == '0')不能
                    @else能
                    @endif
                    </td>
                    <td>
                    @if($v['hot_water'] == '0')没有
                    @else有
                    @endif
                    </td>
                    <td>
                    @if($v['air_conditioner'] == '0')没有
                    @else有
                    @endif
                    </td>
                    <td>
                    @if($v['internet'] == 'null')没有
                    @elseif($v['internet'] == 'wifi')无线
                    @else 有线
                    @endif
                    </td>
                    <td>
                    @if($v['full'] == '0')
                    <button class="btn btn-info btn-sm full" bh="{{$v['id']}}">有房</button>
                    @else
                    <button class="btn btn-pink btn-sm full" bh="{{$v['id']}}">没房</button>
                    @endif
                    </td>
                    <td>
                    <a href="/admin/room/edit/?id={{$v['id']}}" class="btn btn-success btn-sm">编辑信息</a>
                    <a href="/admin/room/editpic/?id={{$v['id']}}" class="btn btn-primary btn-sm">编辑图片</a>
                    <a href="/admin/room/del/?id" class="btn btn-danger btn-sm">删除</a>
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>

        </div>

    <script>
    $('.full').click(function(){
        // if ($(this).text == '有房') 
        // {
        //     $(this).text('满房');
        // }else{
        //     $(this).text('没房');
        // }
        var id = $(this).attr('bh');
        $.ajax({
            type:'get',
            url:"{{url('admin/room/full')}}"+'?id='+id,
            success:function(data){
                if (data.msg == '1') 
                {
                    window.location.reload();
                }else{
                    layer.msg('操作失败,请联系管理员',{icon:5});
                }
            }
        })
    })

    </script>






    @endsection
