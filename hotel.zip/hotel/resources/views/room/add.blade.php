@extends('layout.index')
@section('content')
<script type="text/javascript" src="http://api.map.baidu.com/api?v=1.3"></script>

<div class="page-content">
                        <div class="page-header">
                            <h1>
                               房间管理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    增加房间
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/room/doadd" class="form-horizontal" role="form" method="post" onsubmit="return check()">
                                    <div class="form-group">

                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 房间名称 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 display_name" data-form-un="1479361810862.1565" name="display_name" value="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" name="name" > 房间英文名 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 name" data-form-un="1479361810862.1565" name="name" value="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 房间价格 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1" class="col-xs-10 col-sm-5 price" data-form-un="1479361810862.1565" name="price" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 总房间数 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 count_num" data-form-un="1479361810862.1565" name="count_num" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 房间面积 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 area" data-form-un="1479361810862.1565" name="area" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 可住人数 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 people_num" data-form-un="1479361810862.1565" name="people_num" value="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 房间所在楼层 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 floors" data-form-un="1479361810862.1565" name="floors" value="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 有无早餐 </label>
                                        <div class="col-sm-9">
                                            <select name="breakfast"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="0">无</option>
                                                <option value="1">有</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 可否加床 </label>
                                        <div class="col-sm-9">
                                            <select name="bed_add"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="0">不可以</option>
                                                <option value="1">可以</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 加床价格</label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 bed_add_price" data-form-un="1479361810862.1565" name="bed_add_price" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 单床大小 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 hotel_name" data-form-un="1479361810862.1565" name="bed_area" value="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 可否吸烟 </label>
                                        <div class="col-sm-9">
                                            <select name="smoke"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="0">不可以</option>
                                                <option value="1">可以</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 是否有热水 </label>
                                        <div class="col-sm-9">
                                            <select name="hot_water"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="0">没有</option>
                                                <option value="1">有</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 是否有空调 </label>
                                        <div class="col-sm-9">
                                            <select name="air_conditioner"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="0">没有</option>
                                                <option value="1">有</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 网络情况 </label>
                                        <div class="col-sm-9">
                                            <select name="internet"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                <option value="none">无</option>
                                                <option value="wifi">wifi</option>
                                                <option value="wired">wired</option>
                                            </select>
                                        </div>
                                    </div>

                                    <!-- <input type="hidden" name="admin_id" value=""> -->
                                    <div >
                                        <div class="col-md-offset-3 col-md-9">
                                            <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                增加
                                            </button>

                                            &nbsp; &nbsp; &nbsp;
                                            <button class="btn" type="reset" >
                                                <i class="icon-undo bigger-110"></i>
                                                重置
                                            </button>
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>



<script>
    function check()
    {
            if ($('.display_name').val() == '') 
           {
                layer.msg('请输入酒店名称');
                setTimeout(function(){
                    $('.display_name').focus();
                });
                return false;
           }
            if ($('.name').val() =='') 
           {
                layer.msg('请输入房间英文名');
                setTimeout(function(){
                    $('.name').focus();
                });
                return false;
           }
            if ($('.count_num').val() == '') 
           {
                layer.msg('请输入总房间数');
                setTimeout(function(){
                    $('.count_num').focus();
                });
                return false;
           }
           if ($('.area').val() == '')
           {
                layer.msg('请输入房间面积');
                setTimeout(function(){
                    $('.area').focus();
                });
                return false;
           }
           if ($('.people_num').val() == '') 
           {
                layer.msg('请输入可住人数');
                setTimeout(function(){
                    $('.people_num').focus();
                });
                return false;
           }
           if ($('.floors').val() == '') 
           {
                layer.msg('请输入房间所在楼层');
                setTimeout(function(){
                    $('.floors').focus();
                });
                return false;
           }
    }


</script>

@endsection