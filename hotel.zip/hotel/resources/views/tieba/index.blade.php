@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        帖子管理
        <small>
            <i class="icon-double-angle-right"></i>
             帖子列表
        </small>
                <div style="float:right">
                            <form action="/admin/tieba/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按发帖人查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>帖子名</th>
                    <th>所属贴吧</th>
                    <th>所属分类</th>
                    <th>发帖人</th>
                    <th>帖子内容</th>
                    <th>浏览量</th>
                    <th>评论数</th>
                    <th>关注数</th>
                    <th>分享数</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
    @foreach($list as $v)
                <tr>
                    <td>{{$v['title']}}</td>
                    <td>{{$v['tdn']}}</td>
                    <td>{{$v['tcdn']}} </td>
                    <td>{{$v['nickname']}} </td>
                    <td>{{$v['content']}} </td>
                    <td>{{$v['view_num']}} </td>
                    <td>{{$v['comment_num']}}</td>
                    <td>{{$v['heart_num']}} </td>
                    <td>{{$v['share_num']}} </td>
                    <td>
                        <a href="del/{{$v['id']}}" class="btn btn-danger">删除</a>
                    </td>
                </tr>
    @endforeach
            </tbody>
        </table>
<!-- 分页 -->
       {!!$list->appends($request)->render()!!}
        </div>

    @endsection
