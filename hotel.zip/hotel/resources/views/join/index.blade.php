@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        加入我们
        <small>
            <i class="icon-double-angle-right"></i>
             加入我们
        </small>
                <div style="float:right">
                            <form action="/admin/join/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按姓名查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>姓名</th>
                    <th>联系方式</th>
                    <th>酒店名称</th>
                    <th>酒店地址</th>
                    <th>电子邮箱</th>
                    <th>酒店管理系统使用情况</th>
                </tr>
            </thead>
            <tbody>
    @foreach($list as $v)
                <tr>
                    <td>{{$v['name']}}</td>
                    <td>{{$v['phone']}}</td>
                    <td>{{$v['hotel_name']}}</td>
                    <td>{{$v['hotel_address']}}</td>
                    <td>{{$v['email']}}</td>
                    <td>
                    @if($v['platform'] == 'zlm')
                    住了吗酒店管理系统
                    @elseif($v['platform'] == 'others')
                    其他酒店管理系统
                    @else
                    没有使用酒店管理系统
                    @endif
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>
<!-- 分页 -->
        {!!$list->appends($request)->render()!!}
        </div>
  <script>
    $('.sure').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:'post',
            url:"admin/join/sure",
            data:{'id':id},
            datdType:"json",
            success:function(data)
            {

            }
        })
    })


    </script>
    @endsection
