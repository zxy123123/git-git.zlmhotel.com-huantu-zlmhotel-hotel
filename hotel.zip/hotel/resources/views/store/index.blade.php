@extends('layout.index')
@section('content')
    <style>
        .stage{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .form{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        .stages{
            position:absolute;
            top:0;
            bottom:-300px;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            z-index:999;
            display:none;
        }
        .forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }

        .closes{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
    </style>
      <div class="page-header">
    <h1>
        商品管理
        <small>
            <i class="icon-double-angle-right"></i>
             商品管理
        </small>
                <div style="float:right">
                            <form action="/admin/store/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按商品名查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>
    <body>

                    <div class="page-content">
                        <div class="page-header">

                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <div class="row-fluid">
                                    <ul class="ace-thumbnails">
                                    @foreach($list as $v)
                                        <li>
                                                <a href="/admin/store/goodsdetail?id={{$v['gid']}}"><img alt="150x150" src="/assets/images/gallery/thumb-1.jpg" /></a>
                                                <span>{{$v['gname']}}</span>
                                        </li>
                                    @endforeach
                                    </ul>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div><!-- /.page-content -->


</body>

    @endsection
