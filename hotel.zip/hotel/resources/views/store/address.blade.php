@extends('layout.index')
@section('content')
    <style>
        #stage{
            display:none;
            position:fixed;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.5);
        }
        #forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        #close{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
</style>
      <div class="page-header">
    <h1>
        收货地址管理
        <small>
            <i class="icon-double-angle-right"></i>
             地址列表
        </small>
                <div style="float:right">
                            <form action="/admin/store/address" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按地址查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>联系姓名</th>
                    <th>联系电话</th>
                    <th>地址详情</th>
                    <th>备注</th>
                    <th>默认地址</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
@foreach($list as $v)
                <tr>
                    <td> {{$v['linkman']}}</td>
                    <td>{{$v['phone']}}</td>
                    <td>{{$v['address']}}</td>
                    <td>{{$v['remark']}}</td>
                    <td>
                    @if($v['operate'] == 2)
                    <button class="btn btn-primary deny" bh={{$v['id']}}>√</button>
                    @else
                    <button class="btn btn-primary deny" bh={{$v['id']}}>×</button>
                    @endif
                    </td>
                    <td>
                    <a href="/admin/store/deladd?id={{$v['id']}}" class="btn btn-danger">删除</a>
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>
        <div><button class="btn btn-info btn-sm" id="add">添加地址</button>
    <div   id="stage">
    <div id="forms">
     <form action="/admin/store/addaddress" method="post" onsubmit="return check()" >
         <table  class="table table-striped table-bordered table-hover">
            <tr>
             <th>联系姓名：</th>
             <td><input type="text" class="name" name="linkman" />
             <span class="lm"></span>
             </td>
           </tr>

           <tr>
             <th>联系电话：</th>
             <td><input type="text" class="phone" name="phone" />
              <span class="lxd"></span>
             </td>
           </tr>

           <tr>
             <th>送货地址：</th>
             <td>
              <input type="text" class="address" name="address" placeholder="请填写详细地址">
              <span class="xxadd"></span>
            </td>
           </tr>

           <tr>
             <th>备&nbsp;&nbsp;注：</th>
             <td><input type="text" placeholder="如公司、家" class="weier" name="remark">
             </td>
           </tr>
         </table>
                <center>
                 <div class="bottom">
                   <input type="submit" value="立即添加" class="btn btn-success btn-sm">
                 </div>
                 </center>
                 {{csrf_field()}}
            <span id="close">&times;</span>
        </form>
</div>
    </div>
        </div>
<!-- 分页 -->
{!!$list->appends($request)->render()!!}
        </div>

    <script>
        $('#add').click(function(){
            $('#stage').css('display','block')
        })
        $('#close').click(function(){
            $('#stage').css('display','none')
        })

        function check()
        {
          if ($('.name').val() == '') 
          {
            layer.msg('请输入姓名');
            setTimeout(function(){
              $('.name').focus();
            });
            return false;
          }else if($('.phone').val()==''){
            layer.msg('请输入电话');
            setTimeout(function(){
              $('.phone').focus();
            });
            return false;
          }else if($('.address').val() == ''){
            layer.msg('请输入地址');
            setTimeout(function(){
              $('.address').focus();
            });
            return false;
          }
        }



    $('.deny').click(function(){
        if($(this).text == '√'){
            $(this).text('×');
            // window.location.reload();
        }else{
            $(this).text('√');
            // window.location.reload();
        }
        var id = $(this).attr('bh');
        $.ajax({
            type:'get',
            url:"{{url('admin/store/mo')}}"+'?id='+id,
            success:function(data){
                if (data.msg == '1') 
                {
                    window.location.reload();
                }
            }
        })
    })
    </script>




    @endsection
