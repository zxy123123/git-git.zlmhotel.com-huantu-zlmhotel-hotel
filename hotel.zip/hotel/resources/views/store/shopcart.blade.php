@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        购物车管理
        <small>
            <i class="icon-double-angle-right"></i>
             购物车列表
        </small>
                <div style="float:right">
                            <a href="" class="btn btn-success btn-sm">总计:&nbsp;¥{{$sum}}</a>
                            <a href="/admin/store/dobuy" class="btn btn-pink btn-sm">全部结算</a>
                            <a href="/admin/store/alldel" class="btn btn-info btn-sm">清空购物车</a>
                            <a href="/admin/store/index" class="btn btn-warning btn-sm">继续购物</a>

                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>商品</th>
                    <th>商品名</th>
                    <th>商品价格</th>
                    <th>购买数量</th>
                    <th>小计</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
@foreach($list as $v)
                <tr>
                    <td><a href="/admin/store/goodsdetail?id={{$v['goods_id']}}">{{$v['iname']}}</a></td>
                    <td><a href="/admin/store/goodsdetail?id={{$v['goods_id']}}">{{$v['gname']}}</a></td>
                    <td>¥{{$v['price']}}</td>
                    <td>{{$v['qty']}} </td>
                    <td>¥{{$v['allprice']}} </td>
                    <td>
                        <a href="/admin/store/dobuy?id={{$v['goods_id']}}&qty={{$v['qty']}}" class="btn btn-warning">结算</a>
                        &nbsp;
                        <a href="/admin/store/del?id={{$v['goods_id']}}&qty={{$v['qty']}}" class="btn btn-danger">删除</a>
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>
<!-- 分页 -->

        </div>

    @endsection
