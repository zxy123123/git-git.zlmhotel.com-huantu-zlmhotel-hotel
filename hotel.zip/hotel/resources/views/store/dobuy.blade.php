@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        确认订单
        <small>
            <i class="icon-double-angle-right"></i>
             确认订单
        </small>
<!--                 <div style="float:right">
                            <form action="/admin/tieba/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按发帖人查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div> -->
    </h1>
<h3>收货信息</h3>
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>收货人</th>
                    <th>电话</th>
                    <th>地址</th>
                    <th>备注</th>
                    <th>修改</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{$list['linkman']}}</td>
                    <td>{{$list['phone']}}</td>
                    <td>{{$list['address']}} </td>
                    <td>{{$list['remark']}}</td>
                    <td>
                        <a href="" class="btn btn-pink">修改</a>
                    </td>
                </tr>
            </tbody>
        </table>
        <hr>
<h3>订单信息</h3>
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>商品</th>
                    <th>商品名</th>
                    <th>商品价格</th>
                    <th>购买数量</th>
                    <th>总计</th>
                </tr>
            </thead>
            <tbody>
@foreach($row as $v)
                <tr>
                    <td>{{$v['iname']}} </td>
                    <td>{{$v['gname']}}</td>
                    <td> {{$v['price']}}</td>
                    <td>{{$v['qty']}}</td>
                    <td>{{$v['allprice']}}</td>
@endforeach
                </tr>
            </tbody>
        </table>
    <hr>
<div class="col-xs-4" style="float:right">
        <table class="table table-bordered table-hover">
        <form action="/admin/store/sureorder" method="post">
            <thead>
                <tr align='center' bgcolor="#ccc">
                    <th>确认订单</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                     总计:<input type="text" value="{{$sum}}" readonly name="allprice">
                   </td>
                </tr>
                <tr>
                    <td>
                    <button class="btn btn-success">提交</button></td>
                </tr>
                {{csrf_field()}}
            </tbody>
            </form>
        </table>
        </div>
</div>
    @endsection
