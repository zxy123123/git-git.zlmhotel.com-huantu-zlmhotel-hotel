@extends('layout.index')
@section('content')
      <div class="page-header">
    <h1>
        订单管理
        <small>
            <i class="icon-double-angle-right"></i>
             订单管理
        </small>
                <div style="float:right">
                            <form action="/admin/store/order" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按电话查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>订单编号</th>
                    <th>商品图片</th>
                    <th>商品名</th>
                    <th>收货人</th>
                    <th>收货地址</th>
                    <th>电话</th>
                    <th>数量</th>
                    <th>价格</th>
                    <th>合计</th>
                    <th>订单状态</th>
                </tr>
            </thead>
            <tbody>
@foreach($list as $v)
                <tr>
                    <td>{{$v['ordernum']}}</td>
                    <td> {{$v['iname']}}</td>
                    <td> {{$v['gname']}}</td>
                    <td> {{$v['lname']}}</td>
                    <td>{{$v['address']}}</td>
                    <td>{{$v['phone']}}</td>
                    <td>{{$v['qty']}}</td>
                    <td>{{$v['price']}}</td>
                    <td>{{$v['allprice']}}</td>
                    <td>
                    @if($v['status'] == 0)未发货
                    @elseif($v['status']== 1)已发货
                    @elseif($v['status'] == 2)已完成
                    @else 已失效
                    @endif
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!!$list->appends($request)->render()!!}
        </div>
  <script>
     function other(gid)
    {
        $('.qita_'+gid).fadeIn('1000');
    }
    function message(gid)
    {
        $('.mask_'+gid).fadeIn('1000');
    }

    function guan()
    {
        $('.stages').fadeOut('1000');
    }



    </script>
    @endsection
