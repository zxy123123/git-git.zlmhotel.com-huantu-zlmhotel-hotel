@extends('layout.index')
@section('content')

    <div>
        <div style="float:left;width:50%" >
            <img src="/assets/images/gallery/image-1.jpg" alt="" style="width:100%">
        </div>
        <div style="float:right;width:50%">
            <ul style="list-style:none">
                <h1><li>{{$list['gname']}}</li></h1>
                <h3><li>{{$list['msg']}}</li></h3>
                <h2><li style="color:#FF851B">抢购价: ¥ {{$list['price']}}</li></h2>
            </ul>
        <form action="/admin/store/cartdo" method="get" style="margin-left:30px;margin-top:30px">   
        <input type="hidden" name="goods_id" value="{{$list['goods_id']}}">
        <input type="hidden" name="admin_id" value="{{session('id')}}">
        数量:
                <button type="button" onclick="show()" class="btn btn-success btn-sm">－</button>
                <input type="text" id="count" value="1" name="qty"
                maxlength="3">
                <button type="button" class="btn btn-success btn-sm" onclick="document.getElementById('count').value++">＋</button>
                库存:{{$list['stock']}}
                <div>
                <div style="float:left;margin-left:20px"><button class="btn btn-info" type="submit" name="b" value="add">加入购物车</button></div>
                <div style="margin-top:30px;margin-left:200px"><button class="btn btn-danger" type="submit" name="b" value="buy">立即购买</button></div>
                </div>
        </form>
        </div>

    </div>
    <script>
    function show(){
    var getNum = parseInt(document.getElementById("count").value);
    if(getNum >1){
    document.getElementById("count").value = getNum - 1;
    }else{
    layer.msg('至少一件哦');
    }
    }

    </script>





    @endsection
