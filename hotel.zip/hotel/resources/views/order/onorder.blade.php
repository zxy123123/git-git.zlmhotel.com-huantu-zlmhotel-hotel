@extends('layout.index')
@section('content')
        <script src="/assets/js/jquery.min.js"></script>
        <script src="/assets/layer/layer.js"></script>
        
      <div class="page-header">
    <h1>
        订单管理
        <small>
            <i class="icon-double-angle-right"></i>
             未入住订单
        </small>
                <div style="float:right">
                            <form action="/admin/order/onorder" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按姓名查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                                
                            </form>
                        </div>
    </h1>

        <table class="table table-bordered" style="background:red">
            <thead>
                <tr align='left'>
                    <th>ID</th>
                    <th>用户</th>
                    <th>手机号</th>
                    <th>入住酒店</th>
                    <th>房型</th>
                    <th>单价</th>
                    <th>订房数量</th>
                    <th>入住时间</th>
                    <th>支付状态</th>
                    <th>支付方式</th>
                    <th>订单状态</th>
                    <th>最晚到店时间</th>
                    <th>微信支付的openid</th>
                    <th>特殊要求</th>
                    <th>备注</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($order as $k=>$v)
                <tr>
                    <td>{{$v['oid']}}</td>
                    <td>{{$v['uin']}}</td>
                    <td>{{$v['up']}}</td>
                    <td>{{$v['hn']}}</td>
                    <td>{{$v['rdn']}}

                    </td>
                    <td>{{$v['rp']}}</td>
                    <td>{{$v['orn']}}</td>
                    <td>{{$v['ost']}}</td>
                    <td>
                    @if($v['ops'] == 'paid')
                        已支付
                    @elseif($v['ops'] == 'not_paid')
                        未支付
                     @elseif($v['ops'] == 'paid_fail')
                     支付失败
                    @endif
                    </td>
                    <td>
                    @if($v['opm'] == 'wechat')
                    微信
                    @elseif($v['opm'] == 'score')
                    积分
                    @else
                    到店支付
                    @endif
                    </td>
                    <td>
                    @if($v['oos'] == 'wait_for_pay')
                    等待付款
                    @elseif($v['oos'] == 'wait_for_confirm')
                    等待确认
                    @elseif($v['oos'] == 'success')
                    成功
                    @elseif($v['oos'] == 'cancel')
                    取消
                    @else
                    完成
                    @endif
                    </td>
                    <td>{{$v['olat']}} </td>
                    <td>{{$v['ooi']}} </td>
                    <td> {{$v['osr']}}</td>
                    <td>{{$v['ork']}}</td>
                    <td>
                    <button class="btn btn-success btn-sm check" bh="{{$v['oid']}}">确认入住</button>
                    <a href="/admin/order/ondel/?id={{$v['oid']}}" class="btn btn-pink btn-sm">删除</a>
                </tr>
                @endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!!$order->appends($request)->render()!!}
        </div>

    <script>
    $('.check').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:'post',
            dataType:"json",
            url:"{{URL('admin/order/surecheck')}}",
            data:{'id':id},
            success:function(data){
                        switch(data.msg)
                        {
                            case'1':
                                    layer.msg('入住成功',{icon:6});
                                    window.location.reload();
                                    break;
                            case'2':
                                    layer.msg('入住失败',{icon:5});
                                    break;
                            case'3':
                                    layer.msg('积分少于500无法确认入住',{icon:5});
                        }
            }
        })
    })


function re_fresh() { 
window.location.reload(); 
} 

setTimeout('re_fresh()',300000); //指定5分钟刷新一次 


    </script>

    @endsection
