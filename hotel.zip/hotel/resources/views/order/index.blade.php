@extends('layout.index')
@section('content')

    <style>
        .stage{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .form{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        .stages{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }

        .closes{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
    </style>
      <div class="page-header">
    <h1>
        订单管理
        <small>
            <i class="icon-double-angle-right"></i>
             订单列表
        </small>
                                            @if(session('error'))
                                    <div class="alert alert-danger">
                                         {{session('error')}}
                                    </div>
                                    @endif

                                    @if (count($errors) > 0)
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif

                <div style="float:right">
                            <form action="/admin/order/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按电话查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                                
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>用户</th>
                    <th>电话</th>
                    <th>积分</th>
                    <th>入住时间</th>
                    <th>离店时间</th>
                    <th>支付状态</th>
                    <th>支付方式</th>
                    <th>是否入住</th>
                    <th>入住酒店</th>
                    <th>房型</th>
                    <th>房间单价</th>
                    <th>订房数量</th>
                    <th>订单状态</th>
                    <th>最晚到店时间</th>
                    <th>微信支付的openid</th>
                    <th>特殊要求</th>
                    <th>备注</th>
                    <th width="200">操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($order as $k=>$v)
                <tr>
                    <td>{{$v['oid']}}</td>
                    <td>{{$v['uin']}}</td>
                    <td>{{$v['up']}}</td>
                    <td>{{$v['score']}}</td>
                    <td>{{$v['ost']}}</td>
                    <td>{{$v['oed']}}</td>
                    <td>
                    @if($v['ops'] == 'paid')
                        已支付
                    @elseif($v['ops'] == 'not_paid')
                        未支付
                     @elseif($v['ops'] == 'paid_fail')
                     支付失败
                    @endif
                    </td>
                    <td>
                    @if($v['opm'] == 'wechat')
                    微信
                    @elseif($v['opm'] == 'score')
                    积分
                    @else
                    到店支付
                    @endif
                    </td>
                    <td>
                    @if($v['check_in'] == '0')
                    未入住
                    @else
                    入住
                    @endif
                    </td>
                    <td>{{$v['hn']}}</td>
                    <td>{{$v['rdn']}}</td>
                    <td>{{$v['rp']}}</td>
                    <td>{{$v['orn']}}</td>
                    <td>
                    @if($v['oos'] == 'wait_for_pay')
                    等待付款
                    @elseif($v['oos'] == 'wait_for_confirm')
                    等待确认
                    @elseif($v['oos'] == 'success')
                    成功
                    @elseif($v['oos'] == 'cancel')
                    取消
                    @else
                    完成
                    @endif
                    </td>
                    <td>{{$v['olat']}}</td>
                    <td>{{$v['ooi']}} </td>
                    <td>{{$v['osr']}} </td>
                    <td> {{$v['ork']}}</td>
                    <td>
                        <button class="btn btn-primary btn-sm mask" onclick="remark({{$v['oid']}})">备注</button>
                        <div class="stages mask_{{$v['oid']}}">
                        <div class="forms">
                        <form action="/admin/order/editmask" method="post">
                        <input type="text" name="remark">
                        <input type="hidden" name="id" value="{{$v['oid']}}">
                        <button type="submit" class="btn btn-pink btn-sm">修改备注</button>
                         {{csrf_field()}}
                        </form>
                        <span class="closes " onclick="guan()">&times;</span>
                        </div>
                        </div>      
                        <a href="" class="btn btn-success btn-sm">改签</a>
                        <button class="btn btn-danger btn-sm del" bh= {{$v['oid']}}>删除</button>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!!$order->appends($request)->render()!!}
        </div>
        <script>
    function other(id)
    {
        $('.qita_'+id).fadeIn('1000');
    }
    function remark(id)
    {
        $('.mask_'+id).fadeIn('1000');
    }

    function guan()
    {
        $('.stages').fadeOut('1000');
    }
    
    $('.vvv').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:"post",
            dataType:"json",
            url:"{{URL('admin/order/queren')}}",
            data:{'id':id},
            success:function(data)
            {
                switch(data.msg)
                {
                    case "1":
                            layer.msg('成功入住',{icon:6});
                            window.location.reload();
                            break;
                    case "2":
                            layer.msg('入住失败',{icon:5});
                            break;
                    case "0":
                            layer.msg('不可重复确认入住',{icon:5});
                }
                
            }
        })
    })
    
    $('.del').click(function(){
        var id = $(this).attr('bh');
        if (confirm('确定要删除吗?') == true)
            {
                $.ajax({
                    type:"post",
                    url:"{{url('admin/order/del')}}",
                    data:{'id':id},
                    dataType:"json",
                    success:function(data)
                    {
                        switch(data.msg)
                        {
                            case'1':
                                    layer.msg('删除成功',{icon:6});
                                    window.location.reload();
                                    break;
                            case'2':
                                    layer.msg('删除失败',{icon:5});
                                    break;
                            case'0':
                                    layer.msg('订单未完成无法删除',{icon:5});
                        }
                    }
                })
            } 
    })




</script>



    @endsection
