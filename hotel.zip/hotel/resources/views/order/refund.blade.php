@extends('layout.index')
@section('content')
    <style>
        .stage{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .form{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        .stages{
            position:absolute;
            top:0;
            bottom:-400px;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }

        .closes{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
    </style>
      <div class="page-header">
    <h1>
        订单管理
        <small>
            <i class="icon-double-angle-right"></i>
             退款订单
        </small>
                <div style="float:right">
                            <form action="/admin/order/refund" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按姓名查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                                
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>对应订单</th>
                    <th>用户</th>
                    <th>手机号</th>
                    <th>退款金额</th>
                    <th>退款方式</th>
                    <th>到账时间</th>
                    <th>退款状态</th>
                    <th>备注</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($order as $k=>$v)
                <tr>
                    <td>{{$v['id']}}</td>
                    <td>{{$v['order_id']}}</td>
                    <td>{{$v['uname']}}</td>
                    <td>{{$v['up']}}</td>
                    <td>{{$v['money']}}

                    </td>
                    <td>{{$v['method']}}</td>
                    <td>{{$v['refund_time']}}</td>
                    <td>
                    @if($v['status'] == 'apply')
                        用户请求退款
                    @elseif($v['status'] == 'agree')
                        酒店同意退款
                     @elseif($v['status'] == 'reject')
                     酒店拒绝退款
                     @else 退款到账
                    @endif
                    </td>
                    <td>{{$v['remark']}}</td>
                    <td>
                    <button class="btn btn-success btn-sm agree"  bh={{$v['id']}}>同意退款</button>
                    <button class="btn btn-danger btn-sm refuse" bh={{$v['id']}}>拒绝退款</button>
                    <button class="btn btn-primary btn-sm finish" bh={{$v['id']}}>退款完成</button>
                    <button class="btn btn-warning btn-sm modify" bh={{$v['id']}} onclick="remark({{$v['id']}})">修改备注</button>
                        <div class="stages mask_{{$v['id']}}">
                        <div class="forms">
                        <form action="/admin/order/edmask" method="post">
                        <input type="text" name="remark">
                        <input type="hidden" name="id" value="{{$v['id']}}">
                        <button type="submit" class="btn btn-pink btn-sm" >修改备注</button>
                         {{csrf_field()}}
                        </form>
                        <span class="closes " onclick="guan()">&times;</span>
                        </div>
                        </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!!$order->appends($request)->render()!!}
        </div>
    <script>
     function other(id)
    {
        $('.qita_'+id).fadeIn('1000');
    }
    function remark(id)
    {
        $('.mask_'+id).fadeIn('1000');
    }

    function guan()
    {
        $('.stages').fadeOut('1000');
    }
    

    $('.agree').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:"post",
            url:"{{URL('admin/order/agree')}}",
            dataType:"json",
            data:{'id':id},
            success:function(data){
                switch(data.msg)
                {
                    case "1":
                            layer.msg('已同意退款',{icon:6});
                            window.location.reload();
                            break;
                    case "2":
                            layer.msg('退款失败,请联系管理员',{icon:5});
                            break;
                    case "3":
                            layer.msg('非请求退款状态无法退款',{icon:5});
                }
            }
        })
    })

    $('.refuse').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:"post",
            url:"{{URL('admin/order/refuse')}}",
            dataType:"json",
            data:{'id':id},
            success:function(data){
                switch(data.msg)
                {
                    case "1":
                            layer.msg('已拒绝',{icon:6});
                            window.location.reload();
                            break;
                    case "2":
                            layer.msg('拒绝失败,请联系管理员',{icon:5});
                            break;
                    case "3":
                            layer.msg('非请求退款状态无法拒绝',{icon:5});
                }
            }
        })
    })

    $('.finish').click(function(){
        var id = $(this).attr('bh');
        $.ajax({
            type:"post",
            url:"{{URL('admin/order/finish')}}",
            dataType:"json",
            data:{'id':id},
            success:function(data)
            {
                switch(data.msg)
                {
                    case "1":
                            layer.msg('退款成功完成',{icon:6});
                            window.location.reload();
                            break;
                    case "2":
                            layer.msg('操作失败,请联系管理员',{icon:5});
                            break;
                    case "3":
                            layer.msg('非同意退款状态无法完成',{icon:5});
                }
            }
        })
    })

    </script>
    @endsection
