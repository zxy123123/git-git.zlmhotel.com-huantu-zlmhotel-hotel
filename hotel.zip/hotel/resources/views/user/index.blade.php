@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        酒店经理
        <small>
            <i class="icon-double-angle-right"></i>
             经理列表
        </small>
                <div style="float:right">
                            <form action="/admin/user/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按用户名查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                                
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>酒店</th>
                    <th>用户名</th>
                    <th>电话</th>
                    <th width="250">操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($users as $k=>$v)
                <tr>
                    <td>{{$v['admin_id']}}</td>
                    <td>{{$v['hn']}} </td>
                    <td>{{$v['han']}} </td>
                    <td>{{$v['admin_telephone']}} </td>
                    <td>
                        <a href="delete/{{$v['admin_id']}}" class="btn btn-default">删除</a>
                        <a href="edit/{{$v['admin_id']}}" class="btn btn-primary">修改</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
<!-- 分页 -->
                    {!!$users->appends($request)->render()!!}
        </div>

    @endsection
