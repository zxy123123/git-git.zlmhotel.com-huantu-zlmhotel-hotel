@extends('layout.index')

@section('content')
<div class="page-content">
                        <div class="page-header">
                            <h1>
                                酒店经理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    添加经理
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/user/insert" class="form-horizontal" role="form" method="post">
                                    <div class="form-group">
                                    @if(session('error'))
                                    <div class="alert alert-danger">
                                         {{session('error')}}
                                    </div>
                                    @endif

                                    @if (count($errors) > 0)
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif

                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 用户名 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" name="name" value="{{old('name')}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 酒店名称 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" name="hotelname" value="{{old('hotelname')}}">
                                        </div>
                                    </div>

                                    <div class="space-4"></div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2" > 密码 </label>

                                        <div class="col-sm-9">
                                            <input type="password" id="form-field-2"  class="col-xs-10 col-sm-5" data-form-pw="1479361810862.1565" name="password">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店电话 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5" data-form-pw="1479361810862.1565" name="admin_telephone" value="{{old('admin_telephone')}}">
                                        </div>

                                    </div>

                                    <div >
                                        <div class="col-md-offset-3 col-md-9">
                                            <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                添加
                                            </button>

                                            &nbsp; &nbsp; &nbsp;
                                            <button class="btn" type="reset" >
                                                <i class="icon-undo bigger-110"></i>
                                                重置
                                            </button>
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>
@endsection