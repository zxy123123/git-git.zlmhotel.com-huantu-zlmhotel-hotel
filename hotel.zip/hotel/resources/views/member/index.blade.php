@extends('layout.index')
@section('content')
    <style>
        .stage{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .form{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        .stages{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            z-index:999;
            display:none;
        }
        .forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }

        .closes{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
    </style>
      <div class="page-header">
    <h1>
        用户管理
        <small>
            <i class="icon-double-angle-right"></i>
             用户列表
        </small>
                <div style="float:right">
                            <form action="/admin/member/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按姓名查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                            </form>
                        </div>
        </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>所属酒店</th>
                    <th>昵称</th>
                    <th>姓名</th>
                    <th>性别</th>
                    <th>手机号</th>
                    <th>拥有积分</th>
                    <th>备注</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($res as $k=>$v)
                <tr>
                    <td>{{$v['id']}}</td>
                    <td>{{$v['hotel_id']}}</td>
                    <td>{{$v['nickname']}} </td>
                    <td>11</td>
                    <td>
                    @if($v['gender'] == 'male') 男
                    @elseif($v['gender'] == 'female')女
                    @elseif($v['gender'] == 'secret')保密
                    @endif
                    </td>
                    <td>{{$v['phone_number']}}</td>
                    <td>{{$v['score']}}</td>
                    <td>{{$v['mark']}}</td>
                    <td>
                    <button class="btn btn-success btn-sm" onclick="remark({{$v['id']}})">修改备注</button>
                        <div class="stages mask_{{$v['id']}}">
                        <div class="forms">
                        <form action="/admin/member/edmask" method="post">
                        <input type="text" name="mark">
                        <input type="hidden" name="id" value="{{$v['id']}}">
                        <button type="submit" class="btn btn-pink btn-sm" >修改备注</button>
                         {{csrf_field()}}
                        </form>
                        <span class="closes" onclick="guan()">&times;</span>
                        </div>
                        </div>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
<!-- 分页 -->
 {!!$res->appends($request)->render()!!}
        </div>
    <script>
     function other(id)
    {
        $('.qita_'+id).fadeIn('1000');
    }
    function remark(id)
    {
        $('.mask_'+id).fadeIn('1000');
    }

    function guan()
    {
        $('.stages').fadeOut('1000');
    }

    </script>
    @endsection
