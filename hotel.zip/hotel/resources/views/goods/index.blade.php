@extends('layout.index')
@section('content')
    <style>
        .stage{
            position:absolute;
            top:0;
            bottom:0;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            display:none;
        }
        .form{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }
        .stages{
            position:absolute;
            top:0;
            bottom:-300px;
            left:0;
            right:0;
            background:rgba(0,0,0,0.2);
            z-index:999;
            display:none;
        }
        .forms{
            position:absolute;
            top:50%;
            left:50%;
            transform: translate(-50%,-50%);
            padding:10px;
            background: #fff;
        }

        .closes{
            position:absolute;
            cursor: pointer;
            top:0;
            right:0;
            transform: translate(50%,-50%);
            width:14px;
            height:14px;
            text-align: center;
            line-height:14px;
            border-radius: 100%;
            background:gray;
        }
    </style>
      <div class="page-header">
    <h1>
        商品管理
        <small>
            <i class="icon-double-angle-right"></i>
             商品管理
        </small>
                <div style="float:right">
                            <form action="/admin/goods/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按商品名查找..." value="{{$request['keywords'] or ''}}">
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>商品名</th>
                    <th>商品信息</th>
                    <th>所属分类</th>
                    <th>价格</th>
                    <th>库存</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
@foreach($list as $v)
                <tr>
                    <td>{{$v['iname']}} {{$v['gname']}}</td>
                    <td>
                    <button class="btn btn-primary btn-sm" onclick="message({{$v['gid']}})">详情</button>
                        <div class="stages mask_{{$v['gid']}}">
                        <div class="forms">
                        <form >
                        <textarea name="" id="" cols="30" rows="10">
                        {{$v['msg']}}
                        </textarea>
                         {{csrf_field()}}
                        </form>
                        <span class="closes" onclick="guan()">&times;</span>
                        </div>
                        </div>
                    </td>
                    <td>{{$v['cname']}}</td>
                    <td>{{$v['price']}}</td>
                    <td>{{$v['stock']}}</td>
                    <td> 
                    <a href="/admin/goods/edit?id={{$v['gid']}}" class="btn btn-pink btn-sm">商品信息编辑</a>
                    <a href="" class="btn btn-info btn-sm">商品图片编辑</a>
                    </td>
                </tr>
@endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!! $list->appends($request)->render() !!}
        </div>
  <script>
     function other(gid)
    {
        $('.qita_'+gid).fadeIn('1000');
    }
    function message(gid)
    {
        $('.mask_'+gid).fadeIn('1000');
    }

    function guan()
    {
        $('.stages').fadeOut('1000');
    }



    </script>
    @endsection
