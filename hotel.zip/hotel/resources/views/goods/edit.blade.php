@extends('layout.index')
@section('content')

<div class="page-content">
                        <div class="page-header">
                            <h1>
                                商品管理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    编辑信息
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/goods/update" class="form-horizontal" role="form" method="post" onsubmit="return check()">
                                    <div class="form-group">
                                    <input type="hidden" name="goodsid" value="{{$list['gid']}}">

                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 商品名 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 hotel_name gname" data-form-un="1479361810862.1565" name="gname" value="{{$list['gname']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 商品分类 </label>

                                        <div class="col-sm-9">

                                            <select name="cate_id"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                                @foreach($cate as $k=>$v)
                                                <option value="{{$v['id']}}" @if($list['gcd'] == $v['id']) selected @endif)>{{$v['cname']}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div class="space-4"></div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 价格 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 price" data-form-pw="1479361810862.1565" name="price" value="{{$list['price']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2" > 库存 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 stock" data-form-pw="1479361810862.1565" name="stock" value="{{$list['stock']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店简介 </label>

                                        <div class="col-sm-9">
                                            <textarea name="msg" id="" cols="30" rows="10" class="col-xs-10 col-sm-5 msg" data-form-pw="1479361810862.1565">
                                        {{$list['msg']}}
                                            </textarea>
                                        </div>
                                    </div>

                                    <!-- <input type="hidden" name="admin_id" value=""> -->
                                    <div >
                                        <div class="col-md-offset-3 col-md-9">
                                            <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                修改
                                            </button>

                                            &nbsp; &nbsp; &nbsp;
                                            <button class="btn" type="reset" >
                                                <i class="icon-undo bigger-110"></i>
                                                重置
                                            </button>
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>

<script>
    function check()
    {
            if ($('.gname').val() == '') 
           {
                layer.msg('请输入商品名');
                setTimeout(function(){
                    $('.gname').focus();
                });
                return false;
           }
            if ($('.price').val() =='') 
           {
                layer.msg('请输入商品价格');
                setTimeout(function(){
                    $('.price').focus();
                });
                return false;
           }
            if ($('.stock').val() == '') 
           {
                layer.msg('请输入商品库存');
                setTimeout(function(){
                    $('.stock').focus();
                });
                return false;
           }
           if ($('.msg').val() == '')
           {
                layer.msg('请输入酒店简介');
                setTimeout(function(){
                    $('.msg').focus();
                });
                return false;
           }
    }

</script>

@endsection