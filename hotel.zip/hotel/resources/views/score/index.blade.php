@extends('layout.index')
@section('content')
      <div class="page-header">
    <h1>
        积分管理
        <small>
            <i class="icon-double-angle-right"></i>
             积分列表
        </small>

        </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>贡献酒店名</th>
                    <th>贡献订单数</th>
                    <th>贡献积分数</th>
                </tr>
            </thead>
            <tbody>
    @foreach($list as $k=>$v)
                <tr>
                    <td>{{$v['name']}} </td>
                    <td>{{$v['total']}}</td>
                    <td>{{$v['allscore']}}</td>
                </tr>
        @endforeach
            </tbody>
        </table>
<!-- 分页 -->

        </div>
    <script>


    </script>
    @endsection
