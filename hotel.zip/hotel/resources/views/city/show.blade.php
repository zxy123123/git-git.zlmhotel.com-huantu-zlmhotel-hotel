@extends('layout.index')
@section('content')
      <div class="page-header">
    <h1>
        显示城市管理
        <small>
            <i class="icon-double-angle-right"></i>
             显示城市列表
        </small>
                <div style="float:right">
                            <form action="/admin/city/show" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按城市名查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                            </form>
                        </div>
        </h1>

            <table class="table table-striped table-bordered table-hover">
            <tr>
                <td>
                <select name="address1" id="address1">
                </select>

                <select name="address2" id="address2">
                </select>

                <select name="address3"  id="address3">
                </select>

                <!-- <input type="submit" value="设置" id="shezhi"> -->
                <button class="btn btn-success btn-sm set"> 显示城市</button>
                </td>
                
            </tr>

    </table>



        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>显示城市</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
    @foreach($list as $v)
                <tr>
                    <td bh="{{$v['code']}}">{{$v['fullname']}}</td>
                    <td>
                    <button class="btn btn-success btn-sm cancel">取消显示</button>
                    </td>
                </tr>
    @endforeach
            </tbody>
        </table>
<!-- 分页 -->
{!!$list->appends($request)->render()!!}
        </div>
    <script>
       //三级联动地址
       //获取省份的数据
       $(function(){
        $.ajax({
            type:'get',
            url:"{{url('admin/hotel/addred')}}",
            async:false,
            success:function(data){
                 //console.log(data);
                //将省份信息 追加到 下拉框中
                //先清空原先的数据
                $('#address1').empty();
                //遍历省份数据
                for (var i = 0; i < data.length; i++) {
                    $('<option value="'+data[i].code+'">'+data[i].fullname+'</option>').appendTo('#address1');
                };
            },
            dataType:'json',
        })


        //绑定事件
        $('#address1,#address2,#address3').change(function(){
            var upid = $(this).val();
            // console.log(this);
            // console.log(upid);
            //清空之前的所有数据
            $(this).nextAll('select').empty();
            //保留 $(this) 的值
            var _this = $(this);
            //请求下一级的数据
            $.ajax({
                type:'get',
                url:"{{url('admin/hotel/addred')}}",
                data:"parent_code="+upid,
                success:function(data){
                    // console.log(data);
                    //如果下一级没有数据,就隐藏后面的下拉框
                    // var i=1;
                    if (data == '') {
                        // i++;
                        // console.log(i);
                        _this.nextAll('select').hide();
                        return;
                    }
                    // console.log(data.length);
                    // 填充下一级的数据
                    for (var i = 0; i < data.length; i++) { 
                        // console.log(_this.next('select'));
                        $('<option value="'+data[i].code+'">'+data[i].fullname+'</option>').appendTo(_this.next('select'));

                    }
                    //自动触发 后面的select 的change事件
                     _this.next('select').trigger('change');
                     _this.nextAll('select').show();
                },
                dataType:'json',
            })
        })
        //自动触发 #address1 的change
        $('#address1').trigger('change');
    });

       $('.set').click(function()
       {
            var sheng =$('#address1').val();
            var shi = $('#address2').val();
            var qu = $('#address3').val();
            $.ajax({
                type:"post",
                url:"{{url('admin/city/setshow')}}",
                data:{"sheng":sheng,'shi':shi,'qu':qu},
                success:function(data)
                {
                    switch(data.msg)
                    {
                        case'1':
                                layer.msg('设置成功',{icon:6});
                                window:location.reload();
                                break;
                        case'2':
                                layer.msg('设置失败',{icon:5});
                                break;
                        case'3':
                                layer.msg('已设置显示城市',{icon:5});
                    }
                }
            })
       })

       $('.cancel').click(function(){
        var code = $(this).parent().prev().attr('bh');
        $.ajax({
            type:"post",
            url:"{{url('admin/city/canshow')}}",
            dataType:'json',
            data:{'code':code},
            success:function(data)
            {
                switch(data.msg)
                {
                    case'1':
                        layer.msg('取消成功',{icon:6});
                        window.location.reload();
                        break;
                    case'2':
                        layer.msg('取消失败,请联系管理员',{icon:5});
                }
            }
        })
       })



    </script>
    @endsection
