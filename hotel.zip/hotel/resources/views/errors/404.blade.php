@extends('layout.index')
@section('content')


    </head>
    <body>
<div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <div class="error-container">
                                    <div class="well">
                                        <h1 class="grey lighter smaller">
                                            <span class="blue bigger-125">
                                                <i class="icon-sitemap"></i>
                                                404
                                            </span>
                                            
                                        </h1>

                                        <hr>
                                        <h3 class="lighter smaller" style="font-family:'微软雅黑'">从前有座山,
                                        山里有座庙,庙里有个页面,现在找不到......</h3>

                                        <div>
                                            <div class="space"></div>
                                            <h4 class="smaller"></h4>

                                            <ul class="list-unstyled spaced inline bigger-110 margin-15">
                                                <li>
                                                </li>

                                                <li>
                                                </li>

                                                <li>
                                                </li>
                                            </ul>
                                        </div>

                                        <hr>
                                        <div class="space"></div>

                                        <div class="center">
                                            <a href="/admin" class="btn btn-primary" style="font-family:'微软雅黑">
                                                <i class="icon-dashboard"></i>
                                                我&nbsp;找&nbsp;首&nbsp;页&nbsp;去&nbsp;!
                                            </a>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div>
    </body>
</html>

    @endsection