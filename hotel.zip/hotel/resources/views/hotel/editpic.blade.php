@extends('layout.index')
@section('content')

<div class="page-content">
                        <div class="page-header">
                            <h1>
                                酒店管理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    编辑图片
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/hotel/upload" class="form-horizontal" role="form" method="post" onsubmit="return check()" enctype="multipart/form-data">
                                    <div class="form-group">
                                    <input type="hidden" name="hotel_id" value="">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 上传图片 </label>

                                        <div class="col-sm-9">
                                            <input type="file" name="file">
                                        </div>
                                    </div>


                                    <div >
                                        <div class="col-md-offset-3 col-md-9">
                                           <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                修改
                                            </button> 
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>




<script>
    function check()
    {
            if ($('.name').val() == '') 
           {
                layer.msg('请输入酒店名称');
                setTimeout(function(){
                    $('.name').focus();
                });
                return false;
           }
            if ($('.phone_number').val() =='') 
           {
                layer.msg('请输入酒店电话');
                setTimeout(function(){
                    $('.phone_number').focus();
                });
                return false;
           }
            if ($('.address').val() == '') 
           {
                layer.msg('请输入酒店地址');
                setTimeout(function(){
                    $('.address').focus();
                });
                return false;
           }
           if ($('.longitude').val() == '')
           {
                layer.msg('请输入酒店经度');
                setTimeout(function(){
                    $('.longitude').focus();
                });
                return false;
           }
           if ($('.latitude').val() == '') 
           {
                layer.msg('请输入酒店经度');
                setTimeout(function(){
                    $('.latitude').focus();
                });
                return false;
           }
           if ($('.email').val() == '') 
           {
                layer.msg('请输入酒店邮箱');
                setTimeout(function(){
                    $('.email').focus();
                });
                return false;
           }
           if ($('.routes').val() == '') 
           {
                layer.msg('请输入酒店路线');
                setTimeout(function(){
                    $('.routes').focus();
                });
                return false;
           }
           if ($('.introduction').val() == '') 
           {
                layer.msg('请输入酒店简介');
                setTimeout(function(){
                    $('.introduction').focus();
                });
                return false;
           }

    }


</script>

@endsection