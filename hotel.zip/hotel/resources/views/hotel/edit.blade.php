@extends('layout.index')
@section('content')
<script type="text/javascript" src="http://api.map.baidu.com/api?v=1.3"></script>

<div class="page-content">
                        <div class="page-header">
                            <h1>
                                酒店管理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    编辑信息
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/hotel/update" class="form-horizontal" role="form" method="post" onsubmit="return check()">
                                    <div class="form-group">
<!--                                     @if(session('error'))
                                    <div class="alert alert-danger">
                                         {{session('error')}}
                                    </div>
                                    @endif

                                    @if (count($errors) > 0)
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif -->
                                    <input type="hidden" name="hotel_id" value="{{$list['id']}}">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 酒店名称 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5 hotel_name" data-form-un="1479361810862.1565" name="name" value="{{$list['name']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1"> 酒店星级 </label>

                                        <div class="col-sm-9">
                                     <!--        <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" name="hotel_id" value=""> -->
                                            <select name="grade"  id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" >
                                            <option value="inn" @if($list['grade'] == 'inn') selected @endif>
                                            客栈公寓
                                            </option>
                                            <option value="chain" @if($list['grade'] == 'chain') selected @endif>
                                            经济连锁
                                            </option>
                                            <option value="theme" @if($list['grade'] == 'theme') selected @endif>
                                            主题酒店
                                            </option>
                                            <option value="three_star" @if($list['grade'] == 'three_star') selected @endif>
                                            三星舒适
                                            </option>
                                            <option value="four_star" @if($list['grade'] == 'four_star') selected @endif>
                                            四星高档
                                            </option>
                                            <option value="five_star" @if($list['grade'] == 'five_star') selected @endif>
                                            五星豪华
                                            </option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="space-4"></div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店电话 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 hotel_telephone" data-form-pw="1479361810862.1565" name="phone_number" value="{{$list['phone_number']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店地址 </label>
                                        <div style="float:left">
                                        <select name="address1" id="address1" >
                                        </select>
                                        <select name="address2" id="address2">
                                        </select>

                                        <select name="address3"  id="address3">
                                        </select>
                                               </div>

                                        <div>
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-2 address" data-form-pw="1479361810862.1565" name="address" value="{{$list['address']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2" > 地址经度 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 longitude" data-form-pw="1479361810862.1565" placeholder="请在底部的地图上查询经度" name="longitude" value="{{$list['longitude']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 地址纬度 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 latitude" data-form-pw="1479361810862.1565" placeholder="请在底部的地图上查询纬度" name="latitude" value="{{$list['latitude']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店邮箱 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-2"  class="col-xs-10 col-sm-5 hotel_email" data-form-pw="1479361810862.1565" name="email" value="{{$list['email']}}">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 基础设施 </label>

                                        <div class="col-sm-9">
                                            <label><input name="checkbox[]" type="checkbox" value="1" @if(in_array(1,$arr)) checked @endif />停车场 </label> 
                                            <label><input name="checkbox[]" type="checkbox" value="2" @if(in_array(2,$arr)) checked @endif/>游泳池 </label> 
                                            <label><input name="checkbox[]" type="checkbox" value="3" @if(in_array(3,$arr)) checked @endif/>接送服务 </label> 
                                            <label><input name="checkbox[]" type="checkbox" value="4" @if(in_array(4,$arr)) checked @endif/>健身房 </label> 
                                            <label><input name="checkbox[]" type="checkbox" value="5" @if(in_array(5,$arr)) checked @endif/>社交圈 </label> 
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 路线 </label>

                                        <div class="col-sm-9">
                                            <textarea name="routes" id="" cols="30" rows="5" class="col-xs-10 col-sm-5 routes" data-form-pw="1479361810862.1565">{{$list['routes']}}</textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-2"> 酒店简介 </label>

                                        <div class="col-sm-9">
                                            <textarea name="introduction" id="" cols="30" rows="10" class="col-xs-10 col-sm-5 introduction" data-form-pw="1479361810862.1565">{{$list['introduction']}}</textarea>
                                        </div>
                                    </div>

                                    <!-- <input type="hidden" name="admin_id" value=""> -->
                                    <div >
                                        <div class="col-md-offset-3 col-md-9">
                                            <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                修改
                                            </button>

                                            &nbsp; &nbsp; &nbsp;
                                            <button class="btn" type="reset" >
                                                <i class="icon-undo bigger-110"></i>
                                                重置
                                            </button>
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>

    <div style="width:730px;margin:auto;">   
        要查询的地址：<input id="text_" type="text" value="徐州古彭广场" style="margin-right:100px;"/>
        查询结果(经纬度)：<input id="result_" type="text" />
        <input type="button" value="查询" onclick="searchByStationName();"/>
        <div id="container" 
            style="
                margin-top:30px; 
                width: 730px; 
                height: 590px; 
                top: 50; 
                border: 1px solid gray;
                overflow:hidden;">
        </div>
    </div>
</div>




<script type="text/javascript">
   var map = new BMap.Map("container");
    map.centerAndZoom("徐州", 12);
    map.enableScrollWheelZoom();    //启用滚轮放大缩小，默认禁用
    map.enableContinuousZoom();    //启用地图惯性拖拽，默认禁用
    map.addControl(new BMap.NavigationControl());  //添加默认缩放平移控件
    map.addControl(new BMap.OverviewMapControl()); //添加默认缩略地图控件
    map.addControl(new BMap.OverviewMapControl({ isOpen: true, anchor: BMAP_ANCHOR_BOTTOM_RIGHT }));   //右下角，打开
    var localSearch = new BMap.LocalSearch(map);
    localSearch.enableAutoViewport(); //允许自动调节窗体大小
function searchByStationName() {
    map.clearOverlays();//清空原来的标注
    var keyword = document.getElementById("text_").value;
    localSearch.setSearchCompleteCallback(function (searchResult) {
        var poi = searchResult.getPoi(0);
        document.getElementById("result_").value = poi.point.lng + "," + poi.point.lat;
        map.centerAndZoom(poi.point, 13);
        var marker = new BMap.Marker(new BMap.Point(poi.point.lng, poi.point.lat));  // 创建标注，为要查询的地方对应的经纬度
        map.addOverlay(marker);
        var content = document.getElementById("text_").value + "<br/><br/>经度：" + poi.point.lng + "<br/>纬度：" + poi.point.lat;
        var infoWindow = new BMap.InfoWindow("<p style='font-size:14px;'>" + content + "</p>");
        marker.addEventListener("click", function () { this.openInfoWindow(infoWindow); });
        // marker.setAnimation(BMAP_ANIMATION_BOUNCE); //跳动的动画
        var jing = poi.point.lng;
        var wei = poi.point.lat;
        console.log(jing)
        console.log(wei)
    });
    localSearch.search(keyword);
} 
</script>

<script>
    function check()
    {
            if ($('.name').val() == '') 
           {
                layer.msg('请输入酒店名称');
                setTimeout(function(){
                    $('.name').focus();
                });
                return false;
           }
            if ($('.phone_number').val() =='') 
           {
                layer.msg('请输入酒店电话');
                setTimeout(function(){
                    $('.phone_number').focus();
                });
                return false;
           }
            if ($('.address').val() == '') 
           {
                layer.msg('请输入酒店地址');
                setTimeout(function(){
                    $('.address').focus();
                });
                return false;
           }
           if ($('.longitude').val() == '')
           {
                layer.msg('请输入酒店经度');
                setTimeout(function(){
                    $('.longitude').focus();
                });
                return false;
           }
           if ($('.latitude').val() == '') 
           {
                layer.msg('请输入酒店经度');
                setTimeout(function(){
                    $('.latitude').focus();
                });
                return false;
           }
           if ($('.email').val() == '') 
           {
                layer.msg('请输入酒店邮箱');
                setTimeout(function(){
                    $('.email').focus();
                });
                return false;
           }
           if ($('.routes').val() == '') 
           {
                layer.msg('请输入酒店路线');
                setTimeout(function(){
                    $('.routes').focus();
                });
                return false;
           }
           if ($('.introduction').val() == '') 
           {
                layer.msg('请输入酒店简介');
                setTimeout(function(){
                    $('.introduction').focus();
                });
                return false;
           }

    }



       //三级联动地址
       //获取省份的数据
       $(function(){
        $.ajax({
            type:'get',
            url:"{{url('admin/hotel/addred')}}",
            async:false,
            success:function(data){
                 //console.log(data);
                //将省份信息 追加到 下拉框中
                //先清空原先的数据
                $('#address1').empty();
                //遍历省份数据
                for (var i = 0; i < data.length; i++) {
                    $('<option value="'+data[i].code+'">'+data[i].fullname+'</option>').appendTo('#address1');
                };
            },
            dataType:'json',
        })


        //绑定事件
        $('#address1,#address2,#address3').change(function(){
            var upid = $(this).val();
            // console.log(this);
            // console.log(upid);
            //清空之前的所有数据
            $(this).nextAll('select').empty();
            //保留 $(this) 的值
            var _this = $(this);
            //请求下一级的数据
            $.ajax({
                type:'get',
                url:"{{url('admin/hotel/addred')}}",
                data:"parent_code="+upid,
                success:function(data){
                    // console.log(data);
                    //如果下一级没有数据,就隐藏后面的下拉框
                    // var i=1;
                    if (data == '') {
                        // i++;
                        // console.log(i);
                        _this.nextAll('select').hide();
                        return;
                    }
                    // console.log(data.length);
                    // 填充下一级的数据
                    for (var i = 0; i < data.length; i++) { 
                        // console.log(_this.next('select'));
                        $('<option value="'+data[i].code+'">'+data[i].fullname+'</option>').appendTo(_this.next('select'));

                    }
                    //自动触发 后面的select 的change事件
                     _this.next('select').trigger('change');
                     _this.nextAll('select').show();
                },
                dataType:'json',
            })
        })
        //自动触发 #address1 的change
        $('#address1').trigger('change');
    });

</script>

@endsection