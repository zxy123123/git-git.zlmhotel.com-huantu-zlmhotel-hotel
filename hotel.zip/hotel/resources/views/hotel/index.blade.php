@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        酒店管理
        <small>
            <i class="icon-double-angle-right"></i>
             酒店管理
        </small>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>酒店名称</th>
                    <th>酒店星级</th>
                    <th>酒店电话</th>
                    <th>酒店地址</th>
                    <th>酒店邮箱</th>
                    <th>酒店积分</th>
                    <th>酒店图片</th>
                    <th>地址经度</th>
                    <th>地址纬度</th>
                    <th>路线</th>
                    <th>酒店介绍</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($res as $k=>$v)
                <tr>
                    <td>{{$v['id']}}</td>
                    <td>{{$v['name']}}</td>
                    <td>{{$v['grade']}}</td>
                    <td>{{$v['phone_number']}}</td>
                    <td>{{$v['address']}}</td>
                    <td>{{$v['email']}}</td>
                    <td></td>
                    <td>{{$v['url']}}</td>
                    <td>{{$v['longitude']}}</td>
                    <td> {{$v['latitude']}} </td>
                    <td> {{$v['routes']}}</td>
                    <td>{{$v['introduction']}}</td>
                    <td>
                    <a href="/admin/hotel/edit/?id={{$v['id']}}" class="btn btn-success btn-sm">编辑信息</a>
                    <a href="/admin/hotel/editpic/?id={{$v['id']}}" class="btn btn-danger btn-sm">编辑图片</a>
                    <a href="/admin/hotel/del/?id={{$v['id']}}" class="btn btn-primary btn-sm">删除</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {!!$res->appends($request)->render()!!}
        </div>

    @endsection
