@extends('layout.index')
@section('content')
      <div class="page-header">
    <h1>
        验证码
        <small>
            <i class="icon-double-angle-right"></i>
             验证码
        </small>

        </h1>


                                    <div class="col-sm-12">
                                        <h3 class="header smaller lighter green">
                                        </h3>

                                        <div class="alert alert-block alert-success">
                                            <p>
                                                <strong>
                                                    <i class="icon-bullhorn"></i>
                                                   {{$time['0']}}的验证码:
                                                </strong>
                                                <h3>
                                               {{$list['verification_code']}}
                                               </h3>
                                            </p>
                                             <br>
                                        </div>

                                        <div class="alert alert-info">
                                        <form action="/admin/hotel/docode" method="post" onsubmit="return check()">
                                            <strong>设置今日验证码:</strong>&nbsp;<input type="text" name="verification_code" class="vode">
                                            <input type="submit" class="btn btn-info btn-sm" value="确定">
                                            {{csrf_field()}}
                                        </form>
                                        </div>
                                    </div><!-- /span -->
        </div>
    <script>
    function check()
    {
        if ($('.vode').val() == '') 
        {
            layer.msg('请输入验证码');
            setTimeout(function(){
                $('.vode').focus();
            })
            return false;
        }
        var shou = /^\d+$/ ;
      if (!shou.test($('.vode').val())) 
      {

            layer.msg('格式有误');
            setTimeout(function(){
                $('.vode').focus();
            })
          return false;
    }

}

    </script>
    @endsection
