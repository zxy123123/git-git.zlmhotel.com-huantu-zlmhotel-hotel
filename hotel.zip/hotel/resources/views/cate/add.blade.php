@extends('layout.index')

@section('content')
<div class="page-content">
                        <div class="page-header">
                            <h1>
                                分类管理
                                <small>
                                    <i class="icon-double-angle-right"></i>
                                    添加分类
                                </small>
                            </h1>
                        </div><!-- /.page-header -->

                        <div class="row">
                            <div class="col-xs-12">
                                <!-- PAGE CONTENT BEGINS -->

                                <form action="/admin/cate/insert" class="form-horizontal" role="form" method="post">
                                    <div class="form-group">
                                    @if(session('error'))
                                    <div class="alert alert-danger">
                                         {{session('error')}}
                                    </div>
                                    @endif

                                    @if (count($errors) > 0)
                                        <div class="alert alert-danger">
                                            <ul>
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @endif

                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 分类名称 </label>

                                        <div class="col-sm-9">
                                            <input type="text" id="form-field-1"  class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565" name="cname" value="{{old('name')}}">
                                        </div>
                                    </div>

                                        <label class="col-sm-3 control-label no-padding-right" for="form-field-1" > 父级分类 </label>
                                        <div class="col-sm-9">
                                            <select name="pid" id="form-field-1" class="col-xs-10 col-sm-5" data-form-un="1479361810862.1565">
                                            <option value="0">一级分类</option>
                                                @foreach($cates as $k=>$v)
                                                <option value="{{$v['id']}}">{{$v['cname']}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div style="margin-top:100px">
                                        <div class="col-md-offset-3 col-md-9">
                                            <button class="btn btn-info" type="submit">
                                                <i class="icon-ok bigger-110"></i>
                                                添加
                                            </button>

                                            &nbsp; &nbsp; &nbsp;
                                            <button class="btn" type="reset" >
                                                <i class="icon-undo bigger-110"></i>
                                                重置
                                            </button>
                                        </div>
                                    </div>
                                    {{csrf_field()}}
                                </form>
                                    <!-- <div class="hr hr-24"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- PAGE CONTENT ENDS -->
                            </div><!-- /.col -->
                        </div><!-- /.row -->
                    </div>
@endsection