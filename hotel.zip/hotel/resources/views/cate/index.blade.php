@extends('layout.index')
@section('content')

      <div class="page-header">
    <h1>
        分类管理
        <small>
            <i class="icon-double-angle-right"></i>
             分类列表
        </small>
                <div style="float:right">
                            <form action="/admin/cate/index" method="get" class="form-search">
                                <input type="submit" class="btn btn-success btn-sm" value="搜索">
                                    <input type="text" name="keywords" placeholder="按电话查找..." value="{{$request['keywords'] or ''}}">
                                    <!-- <i class="icon-search nav-search-icon"></i>  -->
                                
                            </form>
                        </div>
    </h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr align='left' bgcolor="#ccc">
                    <th>ID</th>
                    <th>分类名</th>
                    <th>pid</th>
                    <th>path</th>
                    <th width="250">操作</th>
                </tr>
            </thead>
            <tbody>
            @foreach($cates as $k=>$v)
                <tr>
                    <td>{{$v['id']}}</td>
                    <td>{{$v['cname']}} </td>
                    <td>{{$v['pid']}} </td>
                    <td>{{$v['path']}} </td>
                    <td>
                        <a href="/admin/cate/delete/{{$v['id']}}" class="btn btn-default">删除</a>
                        <a href="/admin/cate/edit/{{$v['id']}}" class="btn btn-primary">修改</a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
<!-- 分页 -->
                   
        </div>

    @endsection
